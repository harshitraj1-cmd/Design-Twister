-- Design Twister 2 · database schema, privacy rules and host actions
-- Run once on a fresh Supabase project (SQL editor or `supabase db push`).
-- Then run supabase/seed.sql for the starter card library.

create extension if not exists pgcrypto;

-- ─────────────────────────────────────────────────────────────
-- Types
-- ─────────────────────────────────────────────────────────────
create type public.card_category as enum ('design_brief', 'budget_material', 'spatial_rules', 'wildcard');
create type public.session_stage as enum ('lobby', 'briefing', 'phase', 'ended');
create type public.app_role as enum ('admin');

-- ─────────────────────────────────────────────────────────────
-- Tables
-- ─────────────────────────────────────────────────────────────
create table public.user_roles (
  user_id uuid not null references auth.users (id) on delete cascade,
  role public.app_role not null,
  primary key (user_id, role)
);

create table public.cards (
  id uuid primary key default gen_random_uuid(),
  category public.card_category not null,
  title text not null check (char_length(btrim(title)) between 1 and 120),
  content text not null default '' check (char_length(content) <= 600),
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.sessions (
  id uuid primary key default gen_random_uuid(),
  room_code varchar(5) not null unique check (room_code ~ '^[A-Z0-9]{5}$'),
  title text not null default '' check (char_length(title) <= 80),
  brief text not null default '' check (char_length(brief) <= 2000),
  stage public.session_stage not null default 'lobby',
  current_phase int not null default 0 check (current_phase between 0 and 4),
  paused boolean not null default false,
  ends_at timestamptz,
  paused_remaining_seconds int,
  briefing_seconds int not null default 300 check (briefing_seconds between 30 and 3600),
  phase_seconds int not null default 600 check (phase_seconds between 30 and 7200),
  distribution_mode text not null default 'balanced' check (distribution_mode in ('balanced', 'random')),
  deal_seq int not null default 0,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);

create table public.participants (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.sessions (id) on delete cascade,
  auth_user_id uuid not null,
  name varchar(40) not null check (char_length(btrim(name)) between 1 and 40),
  joined_at timestamptz not null default now(),
  unique (session_id, auth_user_id)
);
create index participants_session_idx on public.participants (session_id);

-- One row per player per category. revealed = false is the host's preview of the next deal.
create table public.assignments (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.sessions (id) on delete cascade,
  participant_id uuid not null references public.participants (id) on delete cascade,
  card_id uuid not null references public.cards (id) on delete restrict,
  category public.card_category not null,
  revealed boolean not null default false,
  created_at timestamptz not null default now(),
  unique (session_id, participant_id, category)
);
create index assignments_session_cat_idx on public.assignments (session_id, category);
create index assignments_participant_idx on public.assignments (participant_id);

-- ─────────────────────────────────────────────────────────────
-- Helpers
-- ─────────────────────────────────────────────────────────────
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = auth.uid() and role = 'admin');
$$;

create or replace function public.is_member(sid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.participants where session_id = sid and auth_user_id = auth.uid());
$$;

create or replace function public.owns_participant(pid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.participants where id = pid and auth_user_id = auth.uid());
$$;

create or replace function public.phase_category(p int) returns public.card_category
language sql immutable as $$
  select (array['design_brief', 'budget_material', 'spatial_rules', 'wildcard']::public.card_category[])[p];
$$;

create or replace function public.server_now() returns double precision
language sql volatile as $$
  select extract(epoch from clock_timestamp()) * 1000;
$$;

create or replace function public._require_admin() returns void
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then
    raise exception 'Only hosts can do this. Sign in with a host account.' using errcode = '42501';
  end if;
end $$;

-- Picks a card for one player.
-- balanced: the least-used enabled card in this session, ties broken at random,
--           so every card is used once before any card repeats.
-- random:   an unused card while any remain, then any card at random.
create or replace function public._pick_card(sid uuid, cat public.card_category, mode text, exclude uuid default null)
returns uuid
language plpgsql volatile security definer set search_path = public as $$
declare
  picked uuid;
begin
  if mode = 'random' then
    select c.id into picked
    from public.cards c
    left join lateral (select count(*) as n from public.assignments a where a.session_id = sid and a.card_id = c.id) u on true
    where c.enabled and c.category = cat and (exclude is null or c.id <> exclude)
    order by (u.n > 0), random()
    limit 1;
  else
    select c.id into picked
    from public.cards c
    left join lateral (select count(*) as n from public.assignments a where a.session_id = sid and a.card_id = c.id) u on true
    where c.enabled and c.category = cat and (exclude is null or c.id <> exclude)
    order by u.n, random()
    limit 1;
  end if;
  return coalesce(picked, exclude);
end $$;

create or replace function public._category_label(cat public.card_category) returns text
language sql immutable as $$
  select case cat
    when 'design_brief' then 'Design Brief'
    when 'budget_material' then 'Budget & Material'
    when 'spatial_rules' then 'Spatial Rules'
    else 'Wildcard' end;
$$;

-- ─────────────────────────────────────────────────────────────
-- Host actions
-- ─────────────────────────────────────────────────────────────
create or replace function public.create_session(session_title text default '')
returns public.sessions
language plpgsql security definer set search_path = public as $$
declare
  s public.sessions;
  code text;
  alphabet text := 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  i int;
  tries int := 0;
begin
  perform public._require_admin();
  loop
    code := '';
    for i in 1..5 loop
      code := code || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    end loop;
    exit when not exists (select 1 from public.sessions where room_code = code);
    tries := tries + 1;
    if tries > 50 then raise exception 'Could not create a free room code. Try again.'; end if;
  end loop;
  insert into public.sessions (room_code, title, created_by)
  values (code, left(coalesce(btrim(session_title), ''), 80), auth.uid())
  returning * into s;
  return s;
end $$;

-- Fills in the host's preview of the next phase for every player who has none yet.
create or replace function public.prepare_preview(sid uuid)
returns void
language plpgsql security definer set search_path = public as $$
declare
  s public.sessions;
  cat public.card_category;
  pt record;
  cid uuid;
begin
  perform public._require_admin();
  select * into s from public.sessions where id = sid;
  if not found then raise exception 'Session not found.'; end if;
  if s.stage = 'ended' or s.current_phase >= 4 then return; end if;
  cat := public.phase_category(s.current_phase + 1);
  for pt in
    select p.id from public.participants p
    where p.session_id = sid
      and not exists (select 1 from public.assignments a where a.participant_id = p.id and a.category = cat)
    order by p.joined_at
  loop
    cid := public._pick_card(sid, cat, s.distribution_mode);
    if cid is null then
      raise exception 'There are no switched-on % cards. Add or switch on cards in the card library.', public._category_label(cat);
    end if;
    insert into public.assignments (session_id, participant_id, card_id, category, revealed)
    values (sid, pt.id, cid, cat, false);
  end loop;
end $$;

create or replace function public.reshuffle_preview(sid uuid)
returns void
language plpgsql security definer set search_path = public as $$
declare
  s public.sessions;
begin
  perform public._require_admin();
  select * into s from public.sessions where id = sid;
  if not found then raise exception 'Session not found.'; end if;
  if s.stage = 'ended' or s.current_phase >= 4 then return; end if;
  delete from public.assignments
  where session_id = sid and not revealed and category = public.phase_category(s.current_phase + 1);
  perform public.prepare_preview(sid);
end $$;

create or replace function public.reroll_card(sid uuid, pid uuid)
returns void
language plpgsql security definer set search_path = public as $$
declare
  s public.sessions;
  a public.assignments;
  cid uuid;
begin
  perform public._require_admin();
  select * into s from public.sessions where id = sid;
  if not found then raise exception 'Session not found.'; end if;
  if s.stage = 'ended' or s.current_phase >= 4 then raise exception 'There is no upcoming phase to reroll.'; end if;
  select * into a from public.assignments
  where session_id = sid and participant_id = pid and not revealed
    and category = public.phase_category(s.current_phase + 1);
  if not found then
    perform public.prepare_preview(sid);
    return;
  end if;
  cid := public._pick_card(sid, a.category, s.distribution_mode, a.card_id);
  update public.assignments set card_id = cid where id = a.id;
end $$;

create or replace function public.start_briefing(sid uuid)
returns void
language plpgsql security definer set search_path = public as $$
declare
  s public.sessions;
begin
  perform public._require_admin();
  select * into s from public.sessions where id = sid for update;
  if not found then raise exception 'Session not found.'; end if;
  if s.stage <> 'lobby' then raise exception 'The briefing has already started.'; end if;
  if btrim(s.brief) = '' then raise exception 'Write and save the project brief before starting.'; end if;
  update public.sessions
  set stage = 'briefing', paused = false, paused_remaining_seconds = null,
      ends_at = now() + make_interval(secs => briefing_seconds)
  where id = sid;
  perform public.prepare_preview(sid);
end $$;

create or replace function public.deal_phase(sid uuid)
returns void
language plpgsql security definer set search_path = public as $$
declare
  s public.sessions;
  nxt int;
begin
  perform public._require_admin();
  select * into s from public.sessions where id = sid for update;
  if not found then raise exception 'Session not found.'; end if;
  if s.stage = 'ended' then raise exception 'This session has ended.'; end if;
  if s.current_phase >= 4 then raise exception 'All four phases are already dealt.'; end if;
  if btrim(s.brief) = '' then raise exception 'Write and save the project brief before dealing.'; end if;
  perform public.prepare_preview(sid);
  nxt := s.current_phase + 1;
  update public.assignments set revealed = true
  where session_id = sid and category = public.phase_category(nxt);
  update public.sessions
  set stage = 'phase', current_phase = nxt, paused = false, paused_remaining_seconds = null,
      ends_at = now() + make_interval(secs => phase_seconds), deal_seq = deal_seq + 1
  where id = sid;
  perform public.prepare_preview(sid);
end $$;

create or replace function public.pause_session(sid uuid)
returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._require_admin();
  update public.sessions
  set paused = true,
      paused_remaining_seconds = greatest(0, ceil(extract(epoch from (ends_at - now()))))::int
  where id = sid and not paused and ends_at is not null and stage in ('briefing', 'phase');
end $$;

create or replace function public.resume_session(sid uuid)
returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._require_admin();
  update public.sessions
  set paused = false,
      ends_at = now() + make_interval(secs => coalesce(paused_remaining_seconds, 0)),
      paused_remaining_seconds = null
  where id = sid and paused;
end $$;

create or replace function public.add_time(sid uuid, secs int)
returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._require_admin();
  if secs is null or secs < 1 or secs > 3600 then raise exception 'Add between 1 second and 60 minutes.'; end if;
  update public.sessions
  set paused_remaining_seconds = case when paused then coalesce(paused_remaining_seconds, 0) + secs else paused_remaining_seconds end,
      ends_at = case when paused then ends_at else greatest(coalesce(ends_at, now()), now()) + make_interval(secs => secs) end
  where id = sid and stage in ('briefing', 'phase');
end $$;

create or replace function public.end_session(sid uuid)
returns void
language plpgsql security definer set search_path = public as $$
begin
  perform public._require_admin();
  update public.sessions
  set stage = 'ended', paused = false, paused_remaining_seconds = null, ends_at = null
  where id = sid;
  delete from public.assignments where session_id = sid and not revealed;
end $$;

-- ─────────────────────────────────────────────────────────────
-- Player actions
-- ─────────────────────────────────────────────────────────────
-- Joins (or rejoins) a room. Late joiners get a card for every phase already dealt,
-- plus a preview row when the host is already previewing the next phase.
create or replace function public.join_session(code text, player_name text)
returns public.participants
language plpgsql security definer set search_path = public as $$
declare
  s public.sessions;
  p public.participants;
  nm text;
  i int;
  cat public.card_category;
  cid uuid;
begin
  if auth.uid() is null then raise exception 'Your sign-in is missing. Reload the page and try again.'; end if;
  nm := btrim(coalesce(player_name, ''));
  if char_length(nm) < 1 or char_length(nm) > 40 then raise exception 'Use a name between 1 and 40 characters.'; end if;
  select * into s from public.sessions where room_code = upper(btrim(coalesce(code, '')));
  if not found then raise exception 'No room uses that code. Check it with your host.'; end if;
  if s.stage = 'ended' then raise exception 'This session has ended.'; end if;

  select * into p from public.participants where session_id = s.id and auth_user_id = auth.uid();
  if not found then
    if (select count(*) from public.participants where session_id = s.id) >= 120 then
      raise exception 'This room is full.';
    end if;
    insert into public.participants (session_id, auth_user_id, name)
    values (s.id, auth.uid(), nm) returning * into p;
  else
    update public.participants set name = nm where id = p.id returning * into p;
  end if;

  for i in 1..s.current_phase loop
    cat := public.phase_category(i);
    if not exists (select 1 from public.assignments where participant_id = p.id and category = cat) then
      cid := public._pick_card(s.id, cat, s.distribution_mode);
      if cid is not null then
        insert into public.assignments (session_id, participant_id, card_id, category, revealed)
        values (s.id, p.id, cid, cat, true);
      end if;
    end if;
  end loop;

  if s.current_phase < 4 then
    cat := public.phase_category(s.current_phase + 1);
    if exists (select 1 from public.assignments where session_id = s.id and category = cat and not revealed)
       and not exists (select 1 from public.assignments where participant_id = p.id and category = cat) then
      cid := public._pick_card(s.id, cat, s.distribution_mode);
      if cid is not null then
        insert into public.assignments (session_id, participant_id, card_id, category, revealed)
        values (s.id, p.id, cid, cat, false);
      end if;
    end if;
  end if;

  return p;
end $$;

-- The caller's own dealt cards, in phase order.
create or replace function public.my_hand(sid uuid)
returns table (phase int, category public.card_category, title text, content text)
language sql stable security definer set search_path = public as $$
  select array_position(array['design_brief', 'budget_material', 'spatial_rules', 'wildcard']::public.card_category[], a.category) as phase,
         a.category, c.title, c.content
  from public.assignments a
  join public.participants p on p.id = a.participant_id
  join public.cards c on c.id = a.card_id
  where a.session_id = sid and p.auth_user_id = auth.uid() and a.revealed
  order by 1;
$$;

-- ─────────────────────────────────────────────────────────────
-- Row level security
-- ─────────────────────────────────────────────────────────────
alter table public.user_roles enable row level security;
alter table public.cards enable row level security;
alter table public.sessions enable row level security;
alter table public.participants enable row level security;
alter table public.assignments enable row level security;

create policy "read own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

create policy "hosts manage cards" on public.cards
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "hosts manage sessions" on public.sessions
  for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "players read their session" on public.sessions
  for select to authenticated using (public.is_member(id));

create policy "hosts manage participants" on public.participants
  for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "players read their roster" on public.participants
  for select to authenticated using (public.is_member(session_id));

create policy "hosts manage assignments" on public.assignments
  for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "players read their own dealt cards" on public.assignments
  for select to authenticated using (revealed and public.owns_participant(participant_id));

-- Internal helpers are not callable from the app.
revoke execute on function public._pick_card(uuid, public.card_category, text, uuid) from public, anon, authenticated;
revoke execute on function public._require_admin() from public, anon, authenticated;

-- ─────────────────────────────────────────────────────────────
-- Realtime
-- ─────────────────────────────────────────────────────────────
alter publication supabase_realtime add table public.sessions, public.participants, public.assignments;
