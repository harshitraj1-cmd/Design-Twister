-- End-to-end checks of the game rules and privacy policies.
-- Runs in plain Postgres after supabase_stubs.sql, the migration and seed.sql.
\set ON_ERROR_STOP on
\set QUIET on

-- people
insert into auth.users (id) values
  ('00000000-0000-0000-0000-0000000000a1'),
  ('00000000-0000-0000-0000-000000000001'), ('00000000-0000-0000-0000-000000000002'),
  ('00000000-0000-0000-0000-000000000003'), ('00000000-0000-0000-0000-000000000004'),
  ('00000000-0000-0000-0000-000000000005');
insert into public.user_roles values ('00000000-0000-0000-0000-0000000000a1', 'admin');

create or replace function pg_temp.as_user(uid text) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claim.sub', uid, false);
end $$;

create temp table t_ctx (k text primary key, v text);
grant all on t_ctx to authenticated;

-- 1. Host creates a room and writes the brief
set role authenticated;
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
insert into t_ctx select 'sid', id::text from public.create_session('Week 1 studio');
insert into t_ctx select 'code', room_code from public.sessions where id = (select v::uuid from t_ctx where k = 'sid');
update public.sessions set brief = 'Design a co-working lounge for a Korean fintech team in Gurugram.', briefing_seconds = 60, phase_seconds = 120
  where id = (select v::uuid from t_ctx where k = 'sid');
do $$ begin
  assert (select room_code ~ '^[A-HJ-NP-Z2-9]{5}$' from public.sessions limit 1), 'room code uses the 5-character alphabet';
  raise notice 'PASS 1  host created room % with a brief', (select v from t_ctx where k = 'code');
end $$;

-- 2. A player cannot host
select pg_temp.as_user('00000000-0000-0000-0000-000000000001');
do $$ begin
  begin
    perform public.create_session('nope');
    raise exception 'player was able to create a session';
  exception when insufficient_privilege then null;
  end;
  update public.sessions set brief = 'hacked';
  assert (select count(*) from public.cards) = 0, 'player cannot read the card library';
  raise notice 'PASS 2  players cannot host, edit sessions or read the deck';
end $$;

-- 3. Players join; a stranger sees nothing
do $$
declare code text := (select v from t_ctx where k = 'code');
begin
  perform pg_temp.as_user('00000000-0000-0000-0000-000000000001');
  perform public.join_session(lower(code), '  Aanya ');
  perform pg_temp.as_user('00000000-0000-0000-0000-000000000002');
  perform public.join_session(code, 'Rohan');
  perform pg_temp.as_user('00000000-0000-0000-0000-000000000003');
  perform public.join_session(code, 'Meera');
  -- rejoin keeps one row and updates the name
  perform public.join_session(code, 'Meera K');
  assert (select count(*) from public.participants) = 3, 'members see a roster of 3';
  assert (select name from public.participants where auth_user_id = auth.uid()) = 'Meera K', 'rejoin renames';
  assert (select count(*) from public.sessions) = 1, 'member sees own session';
  begin
    perform public.join_session('ZZZZZ', 'Kabir');
    raise exception 'joined a missing room';
  exception when raise_exception then
    if sqlerrm not like 'No room uses that code%' then raise; end if;
  end;
  perform pg_temp.as_user('00000000-0000-0000-0000-000000000005');
  assert (select count(*) from public.sessions) = 0, 'stranger sees no sessions';
  assert (select count(*) from public.participants) = 0, 'stranger sees no roster';
  raise notice 'PASS 3  join, rejoin, bad code and stranger privacy';
end $$;

-- 4. Briefing cannot start without a brief; then starts and builds the Phase 1 preview
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
do $$
declare sid uuid := (select v::uuid from t_ctx where k = 'sid');
begin
  update public.sessions set brief = '   ' where id = sid;
  begin
    perform public.start_briefing(sid);
    raise exception 'briefing started with an empty brief';
  exception when raise_exception then
    if sqlerrm not like 'Write and save the project brief%' then raise; end if;
  end;
  update public.sessions set brief = 'Design a co-working lounge for a Korean fintech team in Gurugram.' where id = sid;
  perform public.start_briefing(sid);
  assert (select stage from public.sessions where id = sid) = 'briefing', 'stage is briefing';
  assert (select count(*) from public.assignments where session_id = sid and category = 'design_brief' and not revealed) = 3, 'three previews';
  raise notice 'PASS 4  empty brief blocked; briefing builds 3 previews';
end $$;

-- 5. Players cannot see previews, even their own
select pg_temp.as_user('00000000-0000-0000-0000-000000000001');
do $$ begin
  assert (select count(*) from public.assignments) = 0, 'preview hidden from player';
  assert (select count(*) from public.my_hand((select v::uuid from t_ctx where k = 'sid'))) = 0, 'hand empty before deal';
  raise notice 'PASS 5  previews stay hidden from players';
end $$;

-- 6. Reroll changes a player's preview card
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
do $$
declare sid uuid := (select v::uuid from t_ctx where k = 'sid');
        pid uuid := (select id from public.participants where auth_user_id = '00000000-0000-0000-0000-000000000001');
        before uuid; after uuid;
begin
  select card_id into before from public.assignments where participant_id = pid and category = 'design_brief';
  perform public.reroll_card(sid, pid);
  select card_id into after from public.assignments where participant_id = pid and category = 'design_brief';
  assert before <> after, 'reroll picked a different card';
  raise notice 'PASS 6  reroll swaps the preview card';
end $$;

-- 7. Deal Phase 1 reveals cards, starts the timer and previews Phase 2
do $$
declare sid uuid := (select v::uuid from t_ctx where k = 'sid'); s public.sessions;
begin
  perform public.deal_phase(sid);
  select * into s from public.sessions where id = sid;
  assert s.stage = 'phase' and s.current_phase = 1 and s.deal_seq = 1, 'phase 1 live';
  assert s.ends_at between now() + interval '119 seconds' and now() + interval '121 seconds', 'timer set to phase length';
  assert (select count(*) from public.assignments where session_id = sid and category = 'design_brief' and revealed) = 3, 'three revealed';
  assert (select count(*) from public.assignments where session_id = sid and category = 'budget_material' and not revealed) = 3, 'phase 2 preview ready';
  raise notice 'PASS 7  deal reveals Phase 1 and prepares Phase 2';
end $$;

-- 8. Each player reads only their own dealt card
select pg_temp.as_user('00000000-0000-0000-0000-000000000001');
do $$
declare sid uuid := (select v::uuid from t_ctx where k = 'sid');
begin
  assert (select count(*) from public.assignments) = 1, 'player sees exactly one assignment row';
  assert (select count(*) from public.my_hand(sid)) = 1, 'hand has one card';
  assert (select title from public.my_hand(sid) where phase = 1) is not null, 'card text readable through my_hand';
  raise notice 'PASS 8  player sees only their own card: "%"', (select title from public.my_hand(sid) where phase = 1);
end $$;

-- 9. Pause, add time while paused, resume, add time while running
select pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
do $$
declare sid uuid := (select v::uuid from t_ctx where k = 'sid'); s public.sessions;
begin
  perform public.pause_session(sid);
  select * into s from public.sessions where id = sid;
  assert s.paused and s.paused_remaining_seconds between 119 and 120, 'paused with remaining time';
  perform public.add_time(sid, 60);
  select * into s from public.sessions where id = sid;
  assert s.paused_remaining_seconds between 179 and 180, 'time added while paused';
  perform public.resume_session(sid);
  select * into s from public.sessions where id = sid;
  assert not s.paused and s.ends_at between now() + interval '178 seconds' and now() + interval '181 seconds', 'resumed';
  perform public.add_time(sid, 300);
  select * into s from public.sessions where id = sid;
  assert s.ends_at between now() + interval '478 seconds' and now() + interval '481 seconds', 'time added while running';
  raise notice 'PASS 9  pause, resume and add time keep the clock right';
end $$;

-- 10. Deal Phase 2, then a late joiner gets both dealt cards and a Phase 3 preview
do $$
declare sid uuid := (select v::uuid from t_ctx where k = 'sid'); code text := (select v from t_ctx where k = 'code');
begin
  perform public.deal_phase(sid);
  perform pg_temp.as_user('00000000-0000-0000-0000-000000000004');
  perform public.join_session(code, 'Kabir');
  assert (select count(*) from public.my_hand(sid)) = 2, 'late joiner holds phases 1 and 2';
  perform pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
  assert (select count(*) from public.assignments a join public.participants p on p.id = a.participant_id
          where p.name = 'Kabir' and a.category = 'spatial_rules' and not a.revealed) = 1, 'late joiner has phase 3 preview';
  raise notice 'PASS 10 late joiner receives every dealt card plus the next preview';
end $$;

-- 11. Balanced dealing spreads cards evenly (12 players, 10 cards)
do $$
declare sid uuid; spread int; i int;
begin
  perform pg_temp.as_user('00000000-0000-0000-0000-0000000000a1');
  sid := (public.create_session('Balance test')).id;
  update public.sessions set brief = 'Test' where id = sid;
  for i in 1..12 loop
    insert into public.participants (session_id, auth_user_id, name) values (sid, gen_random_uuid(), 'P' || i);
  end loop;
  perform public.start_briefing(sid);
  select max(n) - min(n) into spread from (
    select c.id, count(a.id) as n from public.cards c
    left join public.assignments a on a.card_id = c.id and a.session_id = sid
    where c.category = 'design_brief' and c.enabled group by c.id) x;
  assert spread <= 1, 'balanced spread is at most 1';
  -- random mode with enough cards gives no duplicates
  update public.sessions set distribution_mode = 'random' where id = sid;
  delete from public.participants where session_id = sid and name in ('P11', 'P12');
  perform public.reshuffle_preview(sid);
  assert (select count(distinct card_id) = count(*) from public.assignments where session_id = sid), 'random mode: no duplicates when deck >= players';
  raise notice 'PASS 11 balanced spread % and random mode without duplicates', spread;
end $$;

-- 12. No enabled cards gives a clear error; used cards cannot be deleted
do $$
declare sid uuid := (select v::uuid from t_ctx where k = 'sid'); used uuid;
begin
  update public.cards set enabled = false where category = 'spatial_rules';
  delete from public.assignments where session_id = sid and category = 'spatial_rules';
  begin
    perform public.deal_phase(sid);
    raise exception 'dealt with an empty deck';
  exception when raise_exception then
    if sqlerrm not like 'There are no switched-on Spatial Rules cards%' then raise; end if;
  end;
  update public.cards set enabled = true where category = 'spatial_rules';
  select card_id into used from public.assignments where session_id = sid and revealed limit 1;
  begin
    delete from public.cards where id = used;
    raise exception 'deleted a used card';
  exception when foreign_key_violation then null;
  end;
  raise notice 'PASS 12 empty deck message and used-card protection';
end $$;

-- 13. Deal to the end, refuse a fifth deal, end the session and clear previews
do $$
declare sid uuid := (select v::uuid from t_ctx where k = 'sid'); code text := (select v from t_ctx where k = 'code');
begin
  perform public.deal_phase(sid);
  perform public.deal_phase(sid);
  assert (select current_phase from public.sessions where id = sid) = 4, 'phase 4 live';
  assert (select count(*) from public.assignments where session_id = sid and not revealed) = 0, 'no preview after phase 4';
  begin
    perform public.deal_phase(sid);
    raise exception 'dealt a fifth phase';
  exception when raise_exception then
    if sqlerrm not like 'All four phases%' then raise; end if;
  end;
  perform public.end_session(sid);
  assert (select stage from public.sessions where id = sid) = 'ended', 'ended';
  perform pg_temp.as_user('00000000-0000-0000-0000-000000000002');
  assert (select count(*) from public.my_hand(sid)) = 4, 'player keeps four cards after the end';
  perform pg_temp.as_user('00000000-0000-0000-0000-000000000005');
  begin
    perform public.join_session(code, 'Too late');
    raise exception 'joined an ended session';
  exception when raise_exception then
    if sqlerrm not like 'This session has ended%' then raise; end if;
  end;
  raise notice 'PASS 13 four phases, no fifth, ended room keeps hands and refuses joins';
end $$;

reset role;
\echo ALL TESTS PASSED
