# Design Twister 2

A live, constraint-based design game for The Designers Retreat. Everyone gets the same brief. The host deals four rounds of secret constraint cards: Design Brief, Budget & Material, Spatial Rules and a final Wildcard. Each player adapts their design to every card they hold.

Built with React, TypeScript and Vite. Supabase provides the database, sign-in and live updates.

## What is on the site

**Public pages** (no account)
- A hero with a live sample hand you can flip and re-deal, and the join form
- "How it plays" — the four steps
- "The payoff" — the same brief turned into two very different designs
- "The player journey" — a phone mock-up you can click through, with what the host is doing at each moment
- "The session" — a timeline of lobby, briefing and four phases, with the rules for each block
- "Cards and dealing" — the four decks, plus a demo where you set the player count and compare Balanced with Random
- "The host" — a preview table you can reroll, and what the console can do
- "Rules and instructions" — a toggle between the player version and the host version
- "Under the hood" — who can read what, and how the live updates work

## What is in the game

**Players** (phones, no account)
- Join with a 5-character room code and a name; rejoin automatically after a refresh
- Live lobby with everyone who has joined
- Briefing screen with the shared brief and a countdown
- A full-screen 3, 2, 1 before every deal, then a card to tap and flip
- Earlier cards stay on screen as "Still in force"; the brief is one tap away
- Pause banner, low-time warning, and "waiting for the host" states
- Emoji reactions that float up on every screen
- Final screen with all four cards for the debrief
- Day and Night themes, chosen per player

**Host** (laptop, signed in)
- Sessions list: create, open, delete
- Live console: room code and join link, brief editor (locked once the briefing starts), timer lengths, Balanced or Random dealing
- Player table with online status, every dealt card, and a preview of the next deal
- Reroll any single preview, or reshuffle them all, before dealing
- Start briefing, deal each phase (with a confirm step if the timer is still running), end session
- Pause, resume, +1 min and +5 min; every phone follows the server clock
- Remove a player
- Screen-share view for the video call: big code, brief, phase and timer
- Card library: add, edit, switch off, delete (cards already dealt cannot be deleted)

**Fixes over version 1**
- Late joiners get a card for every phase already dealt
- The host can deal before the briefing timer ends, after confirming
- Card privacy is enforced in the database: a player can read only their own dealt cards, and never the host's previews
- Room codes are exactly 5 characters, without look-alike letters (no I, L, O, 0, 1)

## Try it without a server (demo mode)

When no Supabase keys are set, the game runs entirely in one browser. Every tab is a different player.

```bash
npm install
npm run dev
```

Open the host console in one tab (Host a session), then join from other tabs with the room code.

`npm run build:demo` makes a single self-contained HTML file in `dist-demo/` that works the same way.

## Set up the live game

### 1. Create the Supabase project
1. Create a project at supabase.com.
2. In **SQL Editor**, run `supabase/migrations/20261022000000_design_twister.sql`, then `supabase/seed.sql` (40 starter cards).
3. In **Authentication → Sign In / Providers**, switch on **Allow anonymous sign-ins**. Players use this, so they never need an account.

### 2. Make a host account
1. In **Authentication → Users**, add a user with an email and password.
2. In **SQL Editor**, give that user the host role:
   ```sql
   insert into public.user_roles (user_id, role)
   select id, 'admin' from auth.users where email = 'host@example.com';
   ```

### 3. Connect the app
Copy `.env.example` to `.env.local` and fill in the project URL and anon key from **Project Settings → API**:

```
VITE_SUPABASE_URL=https://your-project-ref.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-public-key
```

### 4. Deploy
```bash
npm install
npm run build      # output in dist/
```

Any static host works. Set the same two environment variables in the host's dashboard.

- **Vercel**: `vercel.json` already sends every path to `index.html`.
- **Netlify**: `public/_redirects` already does the same.
- **Lovable**: push this code to the GitHub repository connected to your Lovable project, and add the two variables there.
- If your host cannot send every path to `index.html`, set `VITE_ROUTER=hash`. Links then look like `/#/join/K7P2Q`.

Players join at `https://your-domain/join/CODE`. Hosts go to `/host`.

### Before a full-size session
Run a rehearsal with a few phones. Check your Supabase plan's realtime limits against the room size: 80 players sending emoji reactions creates a lot of live traffic in a short burst.

## How it works

- **Game rules live in the database.** Dealing, rerolls, timers, joining and privacy are Postgres functions and row level security policies in the migration. The app calls them.
- **Previews are hidden rows.** The next phase is dealt in advance with `revealed = false`. Only hosts can read those rows. Dealing flips them to `revealed = true` and starts the timer, all in one step.
- **Balanced dealing** gives each player the least-used switched-on card in that session, so every card is used once before any card repeats. **Random** gives unused cards while they last, then any card.
- **Clocks** count down to `ends_at` on the server. Each phone measures its offset from the server time, so every screen shows the same time.
- **Live updates** use Supabase Realtime: database changes for the game state, broadcast for reactions, and presence for the online dots.

## Project layout

```
src/
  App.tsx                 routes
  pages/Landing.tsx       home page and join form
  pages/Play.tsx          the player game
  pages/Host.tsx          host sign-in, sessions, console, screen-share view, card library
  components/ui.tsx       flip card, timer ring, code boxes, theme switch, toasts, reactions
  components/showcase.tsx the walk-through sections of the public site
  styles/tokens.css       every colour, type and shadow token for Day and Night
  styles/app.css          app shell, controls and game screens
  styles/site.css         the public site sections
  lib/supabaseBackend.ts  live backend
  lib/demoBackend.ts      in-browser backend for demo mode (same rules)
  lib/seedCards.json      starter cards, shared by both backends
supabase/
  migrations/             schema, rules and host actions
  seed.sql                starter cards (regenerate with npm run seed:sql)
  tests/                  database tests for plain Postgres
```

## Database tests

`supabase/tests/game_flow_test.sql` checks 13 rules: privacy, previews, reroll, dealing, pause and add time, late joiners, balanced spread, the empty-deck message, used-card protection, and ending a session. To run it against a throwaway local Postgres 15+:

```bash
createdb dt_test
psql -d dt_test -f supabase/tests/supabase_stubs.sql
psql -d dt_test -f supabase/migrations/20261022000000_design_twister.sql
psql -d dt_test -f supabase/seed.sql
psql -d dt_test -f supabase/tests/game_flow_test.sql
```

Do not run `supabase_stubs.sql` on a real Supabase project.
