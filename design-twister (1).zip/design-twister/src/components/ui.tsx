import {
  createContext, useCallback, useContext, useEffect, useRef, useState,
  type PointerEvent as RPointerEvent, type ReactNode,
} from 'react';
import { DEMO_MODE } from '../lib/config';
import { catByKey, cleanCode, formatClock, ROOM_CODE_LENGTH } from '../lib/game';
import { Link, useRouter } from '../lib/router';
import { useTheme } from '../lib/theme';
import type { Category } from '../lib/types';

export function ThemeToggle({ small }: { small?: boolean }) {
  const [theme, setTheme] = useTheme();
  return (
    <div className={'toggle' + (small ? ' sm' : '')} role="group" aria-label="Colour theme">
      <button type="button" aria-pressed={theme === 'light'} onClick={() => setTheme('light')}>
        Day
      </button>
      <button type="button" aria-pressed={theme === 'dark'} onClick={() => setTheme('dark')}>
        Night
      </button>
    </div>
  );
}

export function Logo({ small, to = '/' }: { small?: boolean; to?: string }) {
  return (
    <Link to={to} className={'logo' + (small ? ' sm' : '')} aria-label="Design Twister home">
      <i aria-hidden="true" />
      <span className="logo-text">Design Twister</span>
    </Link>
  );
}

export function TopBar({ children, links, sections }: { children?: ReactNode; links?: Array<{ to: string; label: string; hideSm?: boolean }>; sections?: ReactNode }) {
  const { path } = useRouter();
  return (
    <header className="topbar">
      <div className="wrap topbar-in">
        <Logo />
        {sections ?? <span className="spacer" />}
        {links?.map((l) => (
          <Link key={l.to} to={l.to} className={'navlink' + (path === l.to ? ' on' : '') + (l.hideSm ? ' hide-sm' : '')}>
            {l.label}
          </Link>
        ))}
        {children}
        <ThemeToggle />
      </div>
    </header>
  );
}

export function DemoNote() {
  if (!DEMO_MODE) return null;
  return (
    <div className="demo-note">
      <div className="wrap">
        <b>Demo mode.</b>
        <span className="long">Everything stays in this browser. Open the host console in one tab and join as players from other tabs.</span>
        <span className="short">Games stay in this browser.</span>
      </div>
    </div>
  );
}

/** The game's card. Face down it is a blueprint sheet; it flips to show the constraint. */
export function FlipCard({
  category, title, content, flipped, onFlip, big, frontLabel = 'Tap to flip', backHint, still,
}: {
  category: Category;
  title: string;
  content?: string;
  flipped: boolean;
  onFlip?: () => void;
  big?: boolean;
  frontLabel?: string;
  backHint?: string;
  still?: boolean;
}) {
  const c = catByKey(category);
  const ref = useRef<HTMLButtonElement | null>(null);

  // The card leans toward the pointer, so it reads as an object rather than a panel.
  const tilt = (e: RPointerEvent<HTMLButtonElement>) => {
    const el = ref.current;
    if (!el || e.pointerType !== 'mouse') return;
    const r = el.getBoundingClientRect();
    el.style.setProperty('--ry', `${((e.clientX - r.left) / r.width - 0.5) * 11}deg`);
    el.style.setProperty('--rx', `${(0.5 - (e.clientY - r.top) / r.height) * 8}deg`);
  };
  const level = () => {
    const el = ref.current;
    if (!el) return;
    el.style.setProperty('--ry', '0deg');
    el.style.setProperty('--rx', '0deg');
  };

  return (
    <button
      ref={ref}
      type="button"
      className={`flip ${c.cls}${flipped ? ' flipped' : ''}${big ? ' big' : ''}${still ? ' still' : ''}`}
      onClick={onFlip}
      onPointerMove={tilt}
      onPointerLeave={level}
      aria-label={flipped ? `${c.label}: ${title}` : `Flip your ${c.label} card`}
    >
      <div className="in">
        <div className="fb blueprint" aria-hidden={flipped}>
          <small>{c.label}</small>
          <span className="mark">
            <b>?</b>
          </span>
          <small>{frontLabel}</small>
        </div>
        <div className="ff" aria-hidden={!flipped}>
          <span className="tag">{c.label}</span>
          <strong>{title}</strong>
          {content ? <p>{content}</p> : null}
          <em>{backHint ?? c.hint}</em>
        </div>
      </div>
    </button>
  );
}

/** Countdown with a ring that drains as the phase runs out. */
export function TimerRing({
  remaining, total, paused, label, categoryCls,
}: {
  remaining: number | null;
  total: number;
  paused: boolean;
  label: string;
  categoryCls?: string;
}) {
  const p = remaining === null || total <= 0 ? 1 : Math.max(0, Math.min(1, remaining / total));
  const low = !paused && remaining !== null && remaining <= 30 && remaining > 0;
  return (
    <div className={'timerbox' + (paused ? ' paused' : '') + (categoryCls ? ' ' + categoryCls : '')} role="timer">
      <div className="ring" style={{ ['--p' as string]: String(p) }}>
        <span className="face">
          <span className={'timer' + (low ? ' low' : '')}>{formatClock(remaining)}</span>
        </span>
      </div>
      <span className="lbl">{paused ? 'Paused by the host' : remaining === 0 ? 'Time is up' : label}</span>
    </div>
  );
}

export function CodeBoxes({ value, onChange, id, autoFocus }: { value: string; onChange: (v: string) => void; id: string; autoFocus?: boolean }) {
  const chars = Array.from({ length: ROOM_CODE_LENGTH }, (_, i) => value[i] ?? '');
  return (
    <div className="codebox">
      {chars.map((ch, i) => (
        <i key={i} className={(ch ? 'filled' : '') + (i === Math.min(value.length, ROOM_CODE_LENGTH - 1) ? ' cur' : '')} aria-hidden="true">
          {ch}
        </i>
      ))}
      <input
        id={id}
        value={value}
        onChange={(e) => onChange(cleanCode(e.target.value))}
        inputMode="text"
        autoCapitalize="characters"
        autoComplete="off"
        autoCorrect="off"
        spellCheck={false}
        maxLength={ROOM_CODE_LENGTH}
        autoFocus={autoFocus}
        aria-label="Room code, 5 characters"
      />
    </div>
  );
}

/* ── toasts ─────────────────────────────────────────── */
interface ToastItem {
  id: number;
  text: string;
  bad?: boolean;
}
const ToastCtx = createContext<(text: string, bad?: boolean) => void>(() => undefined);
export const useToast = () => useContext(ToastCtx);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const next = useRef(1);
  const push = useCallback((text: string, bad?: boolean) => {
    const id = next.current++;
    setItems((x) => [...x.slice(-2), { id, text, bad }]);
    window.setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), bad ? 6000 : 3200);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {items.map((t) => (
          <div key={t.id} className={'toast' + (t.bad ? ' bad' : '')}>
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

/* ── floating reactions ─────────────────────────────── */
interface Floater {
  id: number;
  emoji: string;
  left: number;
}
export function useFloaters(): [Floater[], (emoji: string) => void] {
  const [items, setItems] = useState<Floater[]>([]);
  const next = useRef(1);
  const add = useCallback((emoji: string) => {
    const id = next.current++;
    setItems((x) => [...x.slice(-24), { id, emoji, left: 6 + Math.random() * 86 }]);
    window.setTimeout(() => setItems((x) => x.filter((f) => f.id !== id)), 2400);
  }, []);
  return [items, add];
}

export function Floaters({ items }: { items: Floater[] }) {
  return (
    <div className="floaters" aria-hidden="true">
      {items.map((f) => (
        <span key={f.id} style={{ left: f.left + '%' }}>
          {f.emoji}
        </span>
      ))}
    </div>
  );
}

/** Two-step button for actions that cannot be undone. */
export function ConfirmButton({
  label, confirmText, onConfirm, className = 'btn', disabled, needsConfirm = true,
}: {
  label: string;
  confirmText: string;
  onConfirm: () => void | Promise<void>;
  className?: string;
  disabled?: boolean;
  needsConfirm?: boolean;
}) {
  const [asking, setAsking] = useState(false);
  useEffect(() => {
    if (!asking) return;
    const t = window.setTimeout(() => setAsking(false), 8000);
    return () => window.clearTimeout(t);
  }, [asking]);
  if (asking) {
    return (
      <span className="confirm">
        {confirmText}
        <button type="button" className="btn sm" onClick={() => { setAsking(false); void onConfirm(); }}>
          Yes
        </button>
        <button type="button" className="btn sm alt" onClick={() => setAsking(false)}>
          Cancel
        </button>
      </span>
    );
  }
  return (
    <button type="button" className={className} disabled={disabled} onClick={() => (needsConfirm ? setAsking(true) : void onConfirm())}>
      {label}
    </button>
  );
}
