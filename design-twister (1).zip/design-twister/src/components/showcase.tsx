// The walk-through sections of the public site: what the game is, how a round plays,
// how cards are dealt, what a player sees, and the rules. Every demo here is a
// self-contained illustration — it never touches a real session.
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { CATEGORIES, REACTIONS, shuffle } from '../lib/game';
import { FlipCard, TimerRing } from './ui';

export function Section({
  id, band, kicker, title, lead, children,
}: {
  id?: string;
  band?: 'tint' | 'ink';
  kicker: string;
  title: string;
  lead?: string;
  children: ReactNode;
}) {
  return (
    <section id={id} className={'band' + (band ? ' ' + band : '')}>
      <div className="wrap">
        <div className="sec-head">
          <span className="kicker"><i />{kicker}</span>
          <h2>{title}</h2>
          {lead ? <p className="lead">{lead}</p> : null}
        </div>
        {children}
      </div>
    </section>
  );
}

/* ── 1. the payoff ──────────────────────────────────── */
const HAND_A = [
  ['cat-brief', 'Design Brief', 'A night-shift team that never sleeps'],
  ['cat-budget', 'Budget & Material', 'Reclaimed materials only'],
  ['cat-space', 'Spatial Rules', 'Everything fits in 9 sq m'],
  ['cat-wild', 'Wildcard', 'The client doubles the guest count'],
];
const HAND_B = [
  ['cat-brief', 'Design Brief', 'A team of 12 with one introvert'],
  ['cat-budget', 'Budget & Material', 'Rs 50,000 cap, no exceptions'],
  ['cat-space', 'Spatial Rules', 'No floors. No ceiling.'],
  ['cat-wild', 'Wildcard', 'It must sing at noon'],
];

function Hand2({ who, hand, out }: { who: string; hand: string[][]; out: string }) {
  return (
    <div className="hand2">
      <h3>{who}&rsquo;s hand</h3>
      {hand.map(([cls, label, text]) => (
        <div key={label} className={'mini ' + cls}>
          <small>{label}</small>
          {text}
        </div>
      ))}
      <p className="outcome"><b>Result:</b> {out}</p>
    </div>
  );
}

export function Payoff() {
  return (
    <Section
      id="payoff"
      kicker="The payoff"
      title="One project, very different answers"
      lead="Everyone designs the same thing. The hidden hands pull each design somewhere else, and that is what makes the share-out worth watching."
    >
      <div className="briefbar">
        <span className="tagpill">Shared brief</span>
        Design a co-working lounge for a Korean fintech team in Gurugram.
      </div>
      <div className="vs">
        <Hand2 who="Player A" hand={HAND_A} out="a compact, modular pod lounge built from salvaged parts." />
        <div className="vs-mid" aria-hidden="true">VS</div>
        <Hand2 who="Player B" hand={HAND_B} out="a suspended, sound-led space with tight budget choices." />
      </div>
    </Section>
  );
}

/* ── 2. the four decks and the dealing demo ─────────── */
const DECKS = [
  { cls: 'cat-brief', phase: 'Phase 1', name: 'Design Brief', what: 'An archetype, a core user or a primary challenge.', eg: 'A library for ghosts' },
  { cls: 'cat-budget', phase: 'Phase 2', name: 'Budget & Material', what: 'Cost ceilings, material limits and supply problems.', eg: 'Budget: 3 paperclips' },
  { cls: 'cat-space', phase: 'Phase 3', name: 'Spatial Rules', what: 'Dimensions, site terrain, structure and zoning.', eg: 'No floors. No ceiling.' },
  { cls: 'cat-wild', phase: 'Phase 4', name: 'Wildcard', what: 'A late shock: a new rule, a disaster or a client pivot.', eg: 'It must sing at noon' },
];

const DEMO_DECK = [
  { label: 'No floors', cls: 'cat-brief', letter: 'A' },
  { label: '9 sq m only', cls: 'cat-budget', letter: 'B' },
  { label: 'Steep hillside', cls: 'cat-space', letter: 'C' },
  { label: 'Curved walls', cls: 'cat-wild', letter: 'D' },
  { label: 'Floating site', cls: 'cat-brief', letter: 'E' },
];

export function Decks() {
  const [mode, setMode] = useState<'balanced' | 'random'>('balanced');
  const [count, setCount] = useState(8);
  const [result, setResult] = useState<number[]>([]);

  const deal = (m: 'balanced' | 'random', n: number) => {
    const order = shuffle([0, 1, 2, 3, 4]);
    if (m === 'balanced') setResult(Array.from({ length: n }, (_, i) => order[i % 5]));
    else if (n <= 5) setResult(order.slice(0, n));
    else setResult(Array.from({ length: n }, () => Math.floor(Math.random() * 5)));
  };
  useEffect(() => deal(mode, count), [mode, count]);

  const note =
    mode === 'balanced'
      ? `Balanced deals the shuffled deck round and round, so all 5 cards are used once before any card repeats. ${count > 5 ? `With ${count} players, repeats start at player 6.` : 'Every player has a different card.'}`
      : count <= 5
        ? `Random: with ${count} players and 5 cards, everyone still gets a unique card.`
        : `Random: with ${count} players and only 5 cards, cards are sampled freely, so repeats and uneven spreads are expected.`;

  return (
    <Section
      id="cards"
      band="tint"
      kicker="Cards and dealing"
      title="Four categories, one card each"
      lead="Each phase deals one card from one category. Earlier cards stay on screen, so the constraints stack up through the session."
    >
      <div className="deck4">
        {DECKS.map((d) => (
          <div key={d.name} className={'dk blueprint ' + d.cls}>
            <span className="n">{d.phase}</span>
            <h3>{d.name}</h3>
            <p>{d.what}</p>
            <blockquote>{d.eg}</blockquote>
          </div>
        ))}
      </div>

      <div className="dealbox">
        <h3>How the cards get dealt</h3>
        <p className="lead" style={{ fontSize: '1rem' }}>Balanced uses every card before repeating. Random keeps hands unpredictable. Try both.</p>
        <div className="dctl">
          <div className="seg" role="group" aria-label="Dealing mode">
            <button type="button" aria-pressed={mode === 'balanced'} onClick={() => setMode('balanced')}>Balanced</button>
            <button type="button" aria-pressed={mode === 'random'} onClick={() => setMode('random')}>Random</button>
          </div>
          <label htmlFor="demo-players">
            Players
            <input id="demo-players" type="range" min={3} max={12} value={count} onChange={(e) => setCount(Number(e.target.value))} />
            <b className="num">{count}</b>
          </label>
          <button type="button" className="btn" onClick={() => deal(mode, count)}>Shuffle and deal</button>
        </div>
        <div className="dlabel">Deck: 5 switched-on Spatial Rules cards</div>
        <div className="chiprow">
          {DEMO_DECK.map((d) => (
            <span key={d.letter} className={'pc ' + d.cls}>
              <i style={{ background: 'var(--c)', color: 'var(--on)' }}>{d.letter}</i>
              {d.label}
            </span>
          ))}
        </div>
        <div className="dlabel">Each player&rsquo;s card</div>
        <div className="chiprow">
          {result.map((r, i) => (
            <span key={i} className={'pc ' + DEMO_DECK[r].cls} style={{ animationDelay: `${i * 35}ms` }}>
              <i style={{ background: 'var(--c)', color: 'var(--on)' }}>{DEMO_DECK[r].letter}</i>
              Player {i + 1}
            </span>
          ))}
        </div>
        <p className="dnote">{note}</p>
      </div>
    </Section>
  );
}

/* ── 3. the player journey on a phone ───────────────── */
interface Screen {
  group: string;
  title: string;
  body: ReactNode;
  says: string;
  player: string[];
  host: string[];
}

function ReactionRow() {
  const [counts, setCounts] = useState([12, 8, 21, 5, 9]);
  const [floats, setFloats] = useState<Array<{ id: number; e: string; x: number }>>([]);
  const next = useRef(1);
  const tap = (i: number) => {
    setCounts((c) => c.map((v, k) => (k === i ? v + 1 : v)));
    const id = next.current++;
    setFloats((f) => [...f.slice(-8), { id, e: REACTIONS[i], x: 20 + Math.random() * 200 }]);
    window.setTimeout(() => setFloats((f) => f.filter((x) => x.id !== id)), 1500);
  };
  return (
    <>
      <div className="m-reacts">
        {REACTIONS.map((e, i) => (
          <button key={e} type="button" onClick={() => tap(i)} aria-label={'Send ' + e}>
            {e}
            <small>{counts[i]}</small>
          </button>
        ))}
      </div>
      {floats.map((f) => (
        <span key={f.id} className="m-float" style={{ left: f.x }} aria-hidden="true">{f.e}</span>
      ))}
    </>
  );
}

function PhoneCard({ phase }: { phase: number }) {
  const [flipped, setFlipped] = useState(false);
  const c = CATEGORIES[phase - 1];
  const titles = ['A cafe run entirely by robots', 'Reclaimed materials only', 'No floors. No ceiling.', 'It must sing at noon'];
  return (
    <FlipCard
      still
      category={c.key}
      title={titles[phase - 1]}
      flipped={flipped}
      onFlip={() => setFlipped((f) => !f)}
      frontLabel="Tap to flip"
      backHint="Newest card · tap to hide"
    />
  );
}

function Countdown321() {
  const [n, setN] = useState(3);
  useEffect(() => {
    const t = window.setInterval(() => setN((x) => (x <= 1 ? 3 : x - 1)), 900);
    return () => window.clearInterval(t);
  }, []);
  return (
    <div className="m-overlay blueprint cat-brief">
      <div>
        <div className="big" key={n}>{n}</div>
        <small>Phase 1 · Design Brief</small>
      </div>
    </div>
  );
}

const SCREENS: Screen[] = [
  {
    group: 'Getting in',
    title: 'Join the room',
    body: (
      <>
        <h4>Enter the room code</h4>
        <p>Your host shares a 5-character code on the call.</p>
        <div className="m-code">{['K', '7', 'P', '2', 'Q'].map((c, i) => <i key={i}>{c}</i>)}</div>
        <div className="m-input">Aanya</div>
        <div className="m-btn">Join room</div>
      </>
    ),
    says: 'Players type the room code and a display name. No account and no sign-up.',
    player: ['Enter the 5-character code', 'Choose a display name'],
    host: ['Watches each name appear in the live roster'],
  },
  {
    group: 'Getting in',
    title: 'Lobby',
    body: (
      <>
        <h4>You are in</h4>
        <p>34 players have joined. Waiting for the host to start.</p>
        <div className="m-roster">
          {[['AN', 'Aanya', true], ['RO', 'Rohan', false], ['ME', 'Meera', false], ['KA', 'Kabir', false], ['IS', 'Ishita', false]].map(([ini, nm, me]) => (
            <div key={nm as string}>
              <i>{ini as string}</i>
              {nm as string}
              {me ? <b>You</b> : null}
            </div>
          ))}
        </div>
        <div className="m-btn ghost">Waiting for the host</div>
      </>
    ),
    says: 'A live roster shows who has arrived. Nothing has been dealt yet.',
    player: ['Wait for the session to begin'],
    host: ['Writes and saves the shared brief', 'Cannot start until a brief is saved'],
  },
  {
    group: 'Playing',
    title: 'Briefing',
    body: (
      <>
        <p className="eyebrow">Project brief</p>
        <div className="brief">Design a co-working lounge for a Korean fintech team in Gurugram.</div>
        <p>Read it carefully. Your first constraint card arrives after this countdown.</p>
        <TimerRing remaining={128} total={300} paused={false} label="Briefing time left" categoryCls="cat-space" />
      </>
    ),
    says: 'Everyone sees the same project and the same countdown. No constraint cards are visible yet.',
    player: ['Read the shared brief', 'Start thinking about the project'],
    host: ['Starts the briefing timer, which locks the brief', 'Can skip ahead when the room is ready'],
  },
  {
    group: 'Playing',
    title: '3, 2, 1',
    body: <Countdown321 />,
    says: 'Each phase opens with a full-screen countdown, so the whole room reaches the reveal together.',
    player: ['Watch the countdown'],
    host: ['Has clicked Deal for the phase', 'The phase timer resets to full'],
  },
  {
    group: 'Playing',
    title: 'Your card',
    body: (
      <>
        <span className="chip cat-brief">Phase 1 · Design Brief</span>
        <PhoneCard phase={1} />
        <p>This card is for your eyes only. Tap it in the phone to try.</p>
        <TimerRing remaining={581} total={600} paused={false} label="Phase 1 time left" categoryCls="cat-brief" />
      </>
    ),
    says: 'The new card lands on the player’s screen alone. Tap the card in the phone to flip it.',
    player: ['Flip the card', 'Start adapting the design'],
    host: ['Watches the phase timer', 'Can pause or add time'],
  },
  {
    group: 'Playing',
    title: 'Cards stack up',
    body: (
      <>
        <span className="chip cat-space">Phase 3 · Spatial Rules</span>
        <div className="sc cat-space" style={{ minHeight: 92 }}>
          <small>Phase 3 · Spatial Rules</small>
          <b>No floors. No ceiling.</b>
          <p>Nobody can stand on a floor. Think suspension, slopes or water.</p>
        </div>
        <span className="stack-label">Still in force</span>
        <div className="stack">
          <div className="sc cat-budget"><small>Phase 2 · Budget &amp; Material</small><b>Reclaimed materials only</b></div>
          <div className="sc cat-brief"><small>Phase 1 · Design Brief</small><b>A cafe run entirely by robots</b></div>
        </div>
      </>
    ),
    says: 'Earlier cards stay on screen under "Still in force". By Phase 3 every player is juggling three constraints.',
    player: ['Keep every earlier constraint in mind', 'Rework the design for the new card'],
    host: ['Previews Phase 3 cards before dealing', 'Can reroll any single player'],
  },
  {
    group: 'Playing',
    title: 'Reactions',
    body: (
      <>
        <h4>React to the room</h4>
        <p>Tap to send a live emoji to everyone on the call.</p>
        <ReactionRow />
        <p>Reactions float up on every screen and are never stored.</p>
      </>
    ),
    says: 'Players can cheer or panic at any moment, which keeps a large online room feeling shared. Try tapping an emoji.',
    player: ['Send reactions at any time'],
    host: ['Sees the same reactions, and a running tally'],
  },
  {
    group: 'Finishing',
    title: 'Session ended',
    body: (
      <>
        <p className="eyebrow">Session ended</p>
        <h4>The hand you survived</h4>
        <div className="final">
          {[['cat-brief', 'Phase 1 · Design Brief', 'A cafe run entirely by robots'],
            ['cat-budget', 'Phase 2 · Budget & Material', 'Reclaimed materials only'],
            ['cat-space', 'Phase 3 · Spatial Rules', 'No floors. No ceiling.'],
            ['cat-wild', 'Phase 4 · Wildcard', 'It must sing at noon']].map(([cls, lbl, t]) => (
              <div key={lbl} className={'mini ' + cls}>
                <small>{lbl}</small>
                <b>{t}</b>
              </div>
            ))}
        </div>
      </>
    ),
    says: 'The host closes the room. Players keep their full hand on screen, which is where the debrief starts.',
    player: ['Review the four cards', 'Join the facilitator’s debrief'],
    host: ['Ends the session', 'Internal scores stay on the console'],
  },
];

export function Journey() {
  const [i, setI] = useState(0);
  const s = SCREENS[i];
  let lastGroup = '';
  return (
    <Section
      id="journey"
      kicker="The player journey"
      title="See it on a player's phone"
      lead="Pick a step. The phone shows what a player sees, and the panel beside it shows what the host is doing at the same moment."
    >
      <div className="viewer">
        <div className="steps" role="tablist" aria-label="Game screens">
          {SCREENS.map((sc, k) => {
            const head = sc.group !== lastGroup ? ((lastGroup = sc.group), sc.group) : null;
            return (
              <div key={sc.title} style={{ display: 'contents' }}>
                {head ? <div className="grp">{head}</div> : null}
                <button type="button" role="tab" aria-selected={k === i} onClick={() => setI(k)}>
                  <span>{k + 1}</span>
                  {sc.title}
                </button>
              </div>
            );
          })}
        </div>
        <div className="phone">
          <div className="screen" role="tabpanel" aria-live="polite">{s.body}</div>
        </div>
        <div className="side-notes">
          <h3>{s.title}</h3>
          <p className="lead">{s.says}</p>
          <div className="card2">
            <h5>What the player does</h5>
            <ul>{s.player.map((x) => <li key={x}>{x}</li>)}</ul>
          </div>
          <div className="card2 host">
            <h5>What the host is doing</h5>
            <ul>{s.host.map((x) => <li key={x}>{x}</li>)}</ul>
          </div>
        </div>
      </div>
    </Section>
  );
}

/* ── 4. the session timeline ────────────────────────── */
const STAGES = [
  { n: 'Lobby', t: 'Open', grow: 0.8, kind: 'plain', rules: ['Players join with the 5-character room code and a name.', 'The host writes and saves the project brief.', 'The session cannot start until a brief is saved.'], focus: 'Share the code, watch the roster fill, finish the brief.' },
  { n: 'Briefing', t: '5 min', grow: 1.3, kind: 'ink', rules: ['The host starts the briefing timer and the brief locks.', 'Players see the brief and the countdown. No cards yet.', 'The host can deal early once the room is ready.'], focus: 'Give everyone time to read and think.' },
  { n: 'Phase 1', t: '10 min', grow: 2, kind: 'cat', cls: 'cat-brief', rules: ['One Design Brief card goes to every player.', 'The phase timer resets to its full length.', 'A 3, 2, 1 overlay, then the card flips in.'], focus: 'Previews are checked and rerolled before this deal.' },
  { n: 'Phase 2', t: '10 min', grow: 2, kind: 'cat', cls: 'cat-budget', rules: ['Budget & Material cards are dealt.', 'The Phase 1 card stays on screen under "Still in force".', 'The timer resets again.'], focus: 'Advance when the timer ends, or earlier if the room is ready.' },
  { n: 'Phase 3', t: '10 min', grow: 2, kind: 'cat', cls: 'cat-space', rules: ['Spatial Rules cards are dealt.', 'Three constraints now stack on every design.', 'The timer resets again.'], focus: 'The room is carrying three constraints each.' },
  { n: 'Phase 4', t: '10 min', grow: 2, kind: 'cat', cls: 'cat-wild', rules: ['The Wildcard is dealt: the disruptive final twist.', 'All four cards are visible together.', 'The timer resets for the last time.'], focus: 'The biggest moment of the session.' },
  { n: 'Ended', t: 'Debrief', grow: 0.9, kind: 'plain', rules: ['The host ends the session.', 'Players keep their hands on screen.', 'The room is closed to new joiners.'], focus: 'Run the group debrief and compare designs.' },
];

export function Timeline() {
  const [i, setI] = useState(2);
  const s = STAGES[i];
  return (
    <Section
      id="session"
      band="tint"
      kicker="The session"
      title="About 45 minutes, start to finish"
      lead="Select a block to see its rules. The widths show the suggested time: a 5-minute briefing and four 10-minute phases. The host can change every timer."
    >
      <div className="tl" role="tablist" aria-label="Session stages">
        {STAGES.map((st, k) => (
          <button
            key={st.n}
            type="button"
            role="tab"
            aria-selected={k === i}
            className={st.kind === 'cat' ? 'cat ' + st.cls : st.kind === 'ink' ? 'inkblock' : ''}
            style={{ flexGrow: st.grow }}
            onClick={() => setI(k)}
          >
            <b>{st.n}</b>
            <small>{st.t}</small>
          </button>
        ))}
      </div>
      <div className="tl-scale">
        <span>Doors open</span>
        <span>Briefing, then four phases</span>
        <span>Debrief</span>
      </div>
      <div className="tl-detail">
        <div className="card2">
          <h5>{s.n}: the rules</h5>
          <ul>{s.rules.map((r) => <li key={r}>{r}</li>)}</ul>
        </div>
        <div className="card2 host">
          <h5>Host focus</h5>
          <p>{s.focus}</p>
        </div>
      </div>
      <div className="pausenote">
        <b>Pause and extra time</b>
        The host can pause at any moment and resume, or add 1 or 5 minutes. Every phone counts down from the server clock, so all screens show the same time.
      </div>
    </Section>
  );
}

/* ── 5. the host's preview and reroll ───────────────── */
const SPATIAL = ['No floors. No ceiling.', 'Everything fits in 9 sq m', 'The site is a steep hillside', 'Curved walls only', 'Built on a floating platform'];
const ROSTER = [
  ['Aanya', 'A library for ghosts', 'Reclaimed materials only'],
  ['Rohan', 'A cafe run entirely by robots', 'Budget: 3 paperclips'],
  ['Meera', 'A school that moves every week', 'Cardboard and tape only'],
  ['Kabir', 'A clinic for burned-out superheroes', 'Rs 50,000 cap, no exceptions'],
  ['Ishita', 'A hotel for retired astronauts', 'Nothing you cannot carry'],
];

export function HostPreview() {
  const [picks, setPicks] = useState(() => ROSTER.map((_, i) => i % SPATIAL.length));
  const reroll = (i: number) =>
    setPicks((p) => {
      const next = p.slice();
      let n = next[i];
      while (n === next[i]) n = Math.floor(Math.random() * SPATIAL.length);
      next[i] = n;
      return next;
    });
  return (
    <Section
      id="host"
      kicker="The host"
      title="The host sees every hand"
      lead="Before each deal, the console shows exactly who is about to get which card. Reroll anyone who would get a poor fit, then deal the whole room at once. Try a reroll below."
    >
      <div className="adminbox">
        <div className="adminbox-top">
          <div><span className="pill live">Live</span>&nbsp;&nbsp;Next up: Phase 3 · Spatial Rules</div>
          <div className="tm">02:14</div>
          <div className="fakectrls">
            <span>Pause</span>
            <span>+1 min</span>
            <span>+5 min</span>
            <span className="p">Deal Phase 3</span>
          </div>
        </div>
        <div className="scrollx">
          <table className="atable">
            <thead>
              <tr>
                <th>Player</th>
                <th>Phase 1</th>
                <th>Phase 2</th>
                <th>Phase 3 preview</th>
                <th><span className="sr">Reroll</span></th>
              </tr>
            </thead>
            <tbody>
              {ROSTER.map((r, i) => (
                <tr key={r[0]}>
                  <td><b>{r[0]}</b></td>
                  <td><span className="atag cat-brief">{r[1]}</span></td>
                  <td><span className="atag cat-budget">{r[2]}</span></td>
                  <td><span className="atag dash cat-space">{SPATIAL[picks[i]]}</span></td>
                  <td><button type="button" className="rr" onClick={() => reroll(i)} aria-label={'Reroll ' + r[0]}>Reroll</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div className="feats">
        <div className="card2">
          <h5>Set up</h5>
          <ul>
            <li>Create a room with a 5-character code</li>
            <li>Write the shared brief, which is required to start</li>
            <li>Choose Balanced or Random dealing</li>
            <li>Set the briefing and phase lengths</li>
          </ul>
        </div>
        <div className="card2">
          <h5>Card library</h5>
          <ul>
            <li>Create, edit and delete cards</li>
            <li>Switch a card off without deleting it</li>
            <li>Switched-off cards drop out of future deals</li>
            <li>Four categories, one per phase</li>
          </ul>
        </div>
        <div className="card2">
          <h5>Run the room</h5>
          <ul>
            <li>Start the briefing countdown</li>
            <li>Deal each phase when the room is ready</li>
            <li>Pause, resume and add time</li>
            <li>Open the screen-share view for the call</li>
          </ul>
        </div>
      </div>
    </Section>
  );
}

/* ── 6. rules ───────────────────────────────────────── */
const RULES_PLAYER: Array<[string, string]> = [
  ['Join', 'Enter the 5-character room code and your name. No sign-up.'],
  ['Read the brief', 'During the briefing, everyone sees the same project. No cards yet.'],
  ['Watch the countdown', 'A 3, 2, 1 overlay opens every phase.'],
  ['Flip your card', 'It appears on your screen only. Treat it as binding on your design.'],
  ['Adapt', 'Update the design to respect every card you hold. Earlier cards stay in force.'],
  ['React', 'Send emojis to the room: 💡 😱 🔥 ⏱️ 🤯.'],
  ['Keep going', 'Four phases, four cards, one design that has survived every twist.'],
];
const RULES_HOST: Array<[string, string]> = [
  ['Create the room', 'Share the 5-character code, or the join link, with players.'],
  ['Write and save the brief', 'You cannot start the session with an empty brief.'],
  ['Start the briefing', 'The brief locks and the timer runs. Deal early if the room is ready.'],
  ['Preview, then deal', 'Check each player’s upcoming card, reroll anyone, then deal.'],
  ['Move through the phases', 'Advance when the timer ends, or when you are ready.'],
  ['Steer the clock', 'Pause, resume or add 1 or 5 minutes at any point.'],
  ['End the session', 'Close the room after Phase 4 and run the debrief.'],
];

export function Rules() {
  const [aud, setAud] = useState<'p' | 'h'>('p');
  const list = aud === 'p' ? RULES_PLAYER : RULES_HOST;
  return (
    <Section
      id="rules"
      band="tint"
      kicker="Rules and instructions"
      title="Short enough to explain in a minute"
      lead="Choose who you are explaining it to."
    >
      <div className="seg" role="group" aria-label="Audience" style={{ marginBottom: 24 }}>
        <button type="button" aria-pressed={aud === 'p'} onClick={() => setAud('p')}>For players</button>
        <button type="button" aria-pressed={aud === 'h'} onClick={() => setAud('h')}>For the host</button>
      </div>
      <div className="rules-grid">
        <ol className={'rlist' + (aud === 'h' ? ' host' : '')}>
          {list.map(([t, d]) => (
            <li key={t}>
              <div>
                <b>{t}</b>
                <span>{d}</span>
              </div>
            </li>
          ))}
        </ol>
        <div className="golden">
          <div className="g cat-brief"><b>One card per category</b><span>Every player gets exactly one card in each of the four categories.</span></div>
          <div className="g cat-budget"><b>Constraints stack</b><span>Earlier cards stay in force. The design must respect every card held.</span></div>
          <div className="g cat-space"><b>Private by design</b><span>Players cannot see what anyone else received, on screen or in the database.</span></div>
          <div className="g cat-wild"><b>Scores stay internal</b><span>During the Retreat weeks, scoring is not shared with participants.</span></div>
        </div>
      </div>
    </Section>
  );
}

/* ── 7. under the hood ──────────────────────────────── */
export function UnderTheHood() {
  return (
    <Section id="hood" kicker="Under the hood" title="Private, fair and live">
      <div className="acc">
        <div className="card2">
          <h5>Host</h5>
          <ul>
            <li>A signed-in account with the host role</li>
            <li>Creates and runs sessions, edits the card library</li>
            <li>Sees every player and every assignment</li>
            <li>Can reroll any player before the deal</li>
          </ul>
        </div>
        <div className="card2">
          <h5>Player</h5>
          <ul>
            <li>Joins anonymously with a room code, no sign-up</li>
            <li>Reads the session state and the roster</li>
            <li>Reads only their own dealt cards</li>
            <li>Sends live emoji reactions to the room</li>
          </ul>
        </div>
      </div>
      <div className="sync">
        <div className="card2 cat-brief"><h5>Session updates</h5><p>Phase changes, timers and the brief reach every screen the moment they happen.</p></div>
        <div className="card2 cat-budget"><h5>Private delivery</h5><p>A new card is pushed only to the player it was dealt to.</p></div>
        <div className="card2 cat-space"><h5>One clock</h5><p>Every phone measures its offset from the server, so all countdowns match.</p></div>
        <div className="card2 cat-wild"><h5>Emoji reactions</h5><p>Floating emojis are shared across the room and never stored.</p></div>
      </div>
    </Section>
  );
}

/* ── 8. the programme ───────────────────────────────── */
export function Retreat() {
  return (
    <section className="band" style={{ paddingTop: 0 }}>
      <div className="wrap">
        <div className="retreat">
          <div>
            <h2>Built for The Designers Retreat</h2>
            <p className="lead">Design Twister runs on its own site during the online weeks of the programme, alongside the video call.</p>
          </div>
          <dl>
            <dt>Audience</dt>
            <dd>70 to 80 design students and early-career professionals in Delhi NCR.</dd>
            <dt>Format</dt>
            <dd>Online in Weeks 1 to 3, with a live host steering each session.</dd>
            <dt>Prizes</dt>
            <dd>Rs 1,000 for first place and Rs 500 each for second and third in each competition week.</dd>
            <dt>Scoring</dt>
            <dd>Kept internal. Participants do not see scores during Weeks 1 to 3.</dd>
          </dl>
        </div>
      </div>
    </section>
  );
}
