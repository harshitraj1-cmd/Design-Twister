import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { DemoNote, FlipCard, Floaters, ThemeToggle, TimerRing, useFloaters, useToast } from '../components/ui';
import { debounce, useBackend, useNow, useServerOffset } from '../lib/backend';
import { CATEGORIES, catByPhase, initials, REACTIONS, remainingSeconds } from '../lib/game';
import { useRouter } from '../lib/router';
import type { Backend, HandCard, Membership, Participant, Room, Session } from '../lib/types';

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function writeJson(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage blocked */
  }
}

export function Play({ code }: { code: string }) {
  const backend = useBackend();
  const { navigate } = useRouter();
  const m = useMemo(() => backend?.recallMembership(code) ?? null, [backend, code]);

  useEffect(() => {
    if (backend && !m) navigate('/join/' + code, { replace: true });
  }, [backend, m, code, navigate]);

  if (!backend || !m) {
    return (
      <div className="shell">
        <div className="center-msg"><div className="waiting"><span className="pulse" />Opening the room…</div></div>
      </div>
    );
  }
  return <Game backend={backend} m={m} />;
}

function Game({ backend, m }: { backend: Backend; m: Membership }) {
  const { navigate } = useRouter();
  const toast = useToast();
  const offset = useServerOffset(backend);
  const now = useNow(250) + offset;

  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [hand, setHand] = useState<HandCard[]>([]);
  const [roster, setRoster] = useState<Participant[]>([]);
  const failing = useRef(false);

  const load = useCallback(async () => {
    try {
      const s = await backend.getSession(m.sessionId);
      setSession(s);
      if (!s) return;
      const needRoster = s.stage === 'lobby' || s.stage === 'briefing';
      const [h, r] = await Promise.all([backend.myHand(m.sessionId), needRoster ? backend.getRoster(m.sessionId) : Promise.resolve(null)]);
      setHand(h);
      if (r) setRoster(r);
      if (failing.current) {
        failing.current = false;
        toast('Back online.');
      }
    } catch {
      if (!failing.current) {
        failing.current = true;
        toast('Connection lost. Trying again…', true);
      }
    }
  }, [backend, m.sessionId, toast]);

  useEffect(() => {
    void load();
    const soon = debounce(() => void load(), 250);
    const off = backend.watchSession(m.sessionId, { participantId: m.participantId }, soon);
    const poll = window.setInterval(() => void load(), 20000);
    const onVis = () => {
      if (document.visibilityState === 'visible') void load();
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      off();
      window.clearInterval(poll);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [backend, m.sessionId, m.participantId, load]);

  // reactions and presence
  const [floaters, addFloater] = useFloaters();
  const room = useRef<Room | null>(null);
  useEffect(() => {
    const r = backend.room(m.sessionId);
    room.current = r;
    r.track(m.participantId);
    const off = r.onReaction(addFloater);
    return () => {
      off();
      r.close();
      room.current = null;
    };
  }, [backend, m.sessionId, m.participantId, addFloater]);
  const lastSent = useRef(0);
  const react = (emoji: string) => {
    if (Date.now() - lastSent.current < 450) return;
    lastSent.current = Date.now();
    room.current?.send(emoji);
  };

  // phase reveal: one 3, 2, 1 per phase, then a card to flip
  const seenKey = 'dt-seen-' + m.participantId;
  const flipKey = 'dt-flipped-' + m.participantId;
  const [seenPhase, setSeenPhase] = useState<number>(() => readJson(seenKey, 0));
  const [flipped, setFlipped] = useState<number[]>(() => readJson(flipKey, [] as number[]));
  const [count, setCount] = useState<{ phase: number; n: number } | null>(null);

  useEffect(() => {
    if (!session || session.stage !== 'phase' || count) return;
    if (session.current_phase > seenPhase) setCount({ phase: session.current_phase, n: 3 });
  }, [session, seenPhase, count]);

  useEffect(() => {
    if (!count) return;
    const t = window.setTimeout(() => {
      if (count.n > 1) setCount({ phase: count.phase, n: count.n - 1 });
      else {
        setSeenPhase(count.phase);
        writeJson(seenKey, count.phase);
        setCount(null);
      }
    }, 850);
    return () => window.clearTimeout(t);
  }, [count, seenKey]);

  const toggleFlip = (phase: number) => {
    setFlipped((f) => {
      const next = f.includes(phase) ? f.filter((x) => x !== phase) : [...f, phase];
      writeJson(flipKey, next);
      return next;
    });
  };

  function leave() {
    backend.forgetMembership(m.code);
    navigate('/');
  }

  const remaining = session ? remainingSeconds(session, now) : null;
  const first = m.name.split(/\s+/)[0];

  let body: ReactNode;
  if (session === undefined) {
    body = <div className="waiting"><span className="pulse" />Loading the room…</div>;
  } else if (session === null) {
    body = (
      <div className="center-msg">
        <h1>You are no longer in this room</h1>
        <p>The host may have removed you or closed the session. Join again with the room code.</p>
        <button type="button" className="btn" onClick={() => { backend.forgetMembership(m.code); navigate('/join/' + m.code); }}>
          Join again
        </button>
      </div>
    );
  } else if (session.stage === 'lobby') {
    body = <Lobby first={first} roster={roster} me={m.participantId} />;
  } else if (session.stage === 'briefing') {
    body = <Briefing session={session} remaining={remaining} />;
  } else if (session.stage === 'phase') {
    body = <PhaseView session={session} hand={hand} remaining={remaining} flipped={flipped} onFlip={toggleFlip} />;
  } else {
    body = <Ended session={session} hand={hand} onLeave={leave} />;
  }

  const showBar = session && session.stage !== 'ended';
  const cat = count ? catByPhase(count.phase) : null;

  return (
    <div className="shell">
      <DemoNote />
      <div className="play">
        <div className="play-head">
          <span className="avatar" aria-hidden="true">{initials(m.name)}</span>
          <div className="who">
            <b>{m.name}</b>
            <small>ROOM {m.code}</small>
          </div>
          <span className="spacer" />
          <ThemeToggle small />
        </div>
        {session && session.stage !== 'lobby' ? (
          <div className="phase-rail" aria-label={`Phase ${session.current_phase} of 4`}>
            {CATEGORIES.map((c) => (
              <i
                key={c.key}
                className={c.cls + (session.current_phase > c.phase || session.stage === 'ended' ? ' done' : session.current_phase === c.phase ? ' now' : '')}
              />
            ))}
          </div>
        ) : null}
        {body}
      </div>
      {showBar ? (
        <nav className="reactbar" aria-label="Send a reaction to the room">
          <div className="reactbar-in">
            {REACTIONS.map((e) => (
              <button key={e} type="button" onClick={() => react(e)} aria-label={'Send ' + e}>
                {e}
              </button>
            ))}
          </div>
        </nav>
      ) : null}
      <Floaters items={floaters} />
      {count && cat ? (
        <div className={'countdown blueprint ' + cat.cls} role="alert" aria-live="assertive">
          <div>
            <div className="big" key={count.n}>{count.n}</div>
            <span className="lbl">Phase {count.phase} · {cat.label}</span>
            <div className="sub">Your new card is on its way</div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Lobby({ first, roster, me }: { first: string; roster: Participant[]; me: string }) {
  const shown = roster.slice(0, 40);
  return (
    <>
      <div>
        <p className="eyebrow">You are in</p>
        <h1 className="screen-title">Welcome, {first}</h1>
      </div>
      <div className="panel" style={{ padding: 18, display: 'grid', gap: 14 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <span className="count-big num">{roster.length}</span>
          <span className="muted" style={{ fontWeight: 700 }}>{roster.length === 1 ? 'player in the room' : 'players in the room'}</span>
        </div>
        <div className="roster">
          {shown.map((p) => (
            <span key={p.id} className={p.id === me ? 'me' : ''}>
              <i>{initials(p.name)}</i>
              {p.id === me ? 'You' : p.name}
            </span>
          ))}
          {roster.length > shown.length ? <span>+{roster.length - shown.length} more</span> : null}
        </div>
      </div>
      <div className="waiting"><span className="pulse" />Waiting for the host to start the briefing</div>
      <p className="privacy">Keep this screen open. Everything updates on its own.</p>
    </>
  );
}

function Briefing({ session, remaining }: { session: Session; remaining: number | null }) {
  return (
    <>
      <p className="eyebrow">Project brief · everyone gets the same one</p>
      <div className="brief">{session.brief}</div>
      <TimerRing
        remaining={remaining}
        total={session.briefing_seconds}
        paused={session.paused}
        label="Briefing time left"
        categoryCls="cat-space"
      />
      {remaining === 0 && !session.paused ? (
        <div className="waiting"><span className="pulse" />Waiting for the host to deal Phase 1</div>
      ) : (
        <p className="privacy">Read it carefully. Your first constraint card arrives after this countdown.</p>
      )}
    </>
  );
}

function PhaseView({
  session, hand, remaining, flipped, onFlip,
}: {
  session: Session;
  hand: HandCard[];
  remaining: number | null;
  flipped: number[];
  onFlip: (phase: number) => void;
}) {
  const phase = session.current_phase;
  const cat = catByPhase(phase);
  const newest = hand.find((h) => h.phase === phase);
  const earlier = hand.filter((h) => h.phase < phase).sort((a, b) => b.phase - a.phase);
  const isFlipped = flipped.includes(phase);
  return (
    <>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span className={'chip ' + cat.cls}>Phase {phase} · {cat.label}</span>
        <span className="spacer" />
        <span className="muted num" style={{ fontWeight: 800, fontSize: '.82rem' }}>{phase} OF 4</span>
      </div>
      {newest ? (
        <div className={'cardstage ' + cat.cls} key={phase}>
          <FlipCard
            big
            category={newest.category}
            title={newest.title}
            content={newest.content}
            flipped={isFlipped}
            onFlip={() => onFlip(phase)}
            frontLabel="Tap to flip"
            backHint={phase === 4 ? 'The final twist · tap to hide' : 'Newest card · tap to hide'}
          />
        </div>
      ) : (
        <div className="waiting"><span className="pulse" />Dealing your card…</div>
      )}
      <p className="privacy lockline">
        <span aria-hidden="true">🔒</span>
        {isFlipped ? 'This card is for your eyes only.' : 'Tap the card to see your new constraint.'}
      </p>
      <TimerRing
        remaining={remaining}
        total={session.phase_seconds}
        paused={session.paused}
        label={`Phase ${phase} time left`}
        categoryCls={cat.cls}
      />
      {remaining === 0 && !session.paused ? (
        <div className="waiting">
          <span className="pulse" />
          {phase < 4 ? `Waiting for the host to deal Phase ${phase + 1}` : 'Waiting for the host to end the session'}
        </div>
      ) : null}
      {earlier.length ? (
        <>
          <span className="stack-label">Still in force</span>
          <div className="stack">
            {earlier.map((h) => (
              <div key={h.phase} className={'sc ' + catByPhase(h.phase).cls}>
                <small>Phase {h.phase} · {catByPhase(h.phase).label}</small>
                <b>{h.title}</b>
                {h.content ? <p>{h.content}</p> : null}
              </div>
            ))}
          </div>
        </>
      ) : null}
      <details className="briefdrop">
        <summary>Project brief</summary>
        <div className="brief sm" style={{ marginTop: 10 }}>{session.brief}</div>
      </details>
    </>
  );
}

function Ended({ session, hand, onLeave }: { session: Session; hand: HandCard[]; onLeave: () => void }) {
  return (
    <>
      <div>
        <p className="eyebrow">Session ended</p>
        <h1 className="screen-title">Here is the hand you survived</h1>
      </div>
      <div className="brief sm">{session.brief}</div>
      <div className="final">
        {hand.map((h) => (
          <div key={h.phase} className={'mini ' + catByPhase(h.phase).cls}>
            <small>Phase {h.phase} · {catByPhase(h.phase).label}</small>
            <b>{h.title}</b>
            {h.content ? <p>{h.content}</p> : null}
          </div>
        ))}
        {hand.length === 0 ? <p className="muted">No cards were dealt in this session.</p> : null}
      </div>
      <p className="privacy">Thanks for playing. Bring these four cards to the debrief.</p>
      <button type="button" className="btn alt block" onClick={onLeave}>Back to the start</button>
    </>
  );
}
