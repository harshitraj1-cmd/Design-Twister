import { useEffect, useState, type FormEvent } from 'react';
import { Decks, HostPreview, Journey, Payoff, Retreat, Rules, Section, Timeline, UnderTheHood } from '../components/showcase';
import { CodeBoxes, DemoNote, FlipCard, TopBar } from '../components/ui';
import { useBackend } from '../lib/backend';
import { CATEGORIES, errorText, ROOM_CODE_LENGTH } from '../lib/game';
import { Link, useRouter } from '../lib/router';
import seed from '../lib/seedCards.json';
import type { Category, Membership } from '../lib/types';

const NAME_KEY = 'dt-last-name';
function savedName(): string {
  try {
    return localStorage.getItem(NAME_KEY) ?? '';
  } catch {
    return '';
  }
}

export function JoinForm({ initialCode = '', focusName }: { initialCode?: string; focusName?: boolean }) {
  const backend = useBackend();
  const { navigate } = useRouter();
  const [code, setCode] = useState(initialCode);
  const [name, setName] = useState(savedName);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const ready = code.length === ROOM_CODE_LENGTH && name.trim().length > 0;

  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!backend || !ready) return;
    setBusy(true);
    setErr('');
    try {
      try {
        localStorage.setItem(NAME_KEY, name.trim());
      } catch {
        /* storage blocked */
      }
      const m = await backend.joinRoom(code, name.trim());
      navigate('/play/' + m.code);
    } catch (e2) {
      setErr(errorText(e2));
      setBusy(false);
    }
  }

  return (
    <form className="joincard panel" onSubmit={submit}>
      <h2>Join a game</h2>
      <label className="field" htmlFor="room-code">
        <span>Room code</span>
        <CodeBoxes id="room-code" value={code} onChange={setCode} autoFocus={!initialCode && !focusName} />
      </label>
      <label className="field" htmlFor="player-name">
        <span>Your name</span>
        <input
          id="player-name"
          className="input"
          value={name}
          maxLength={40}
          autoComplete="nickname"
          placeholder="How the host will see you"
          onChange={(e) => setName(e.target.value)}
          autoFocus={focusName}
        />
      </label>
      {err ? <p className="error" role="alert">{err}</p> : null}
      <button className="btn lg block" type="submit" disabled={!ready || busy || !backend}>
        {busy ? 'Joining…' : 'Join room'}
        <span className="arr" aria-hidden="true">→</span>
      </button>
      <small className="muted">No sign-up. Your host shares the 5-character code on the call.</small>
    </form>
  );
}

const pick = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];
const SEED = seed as Array<{ category: Category; title: string; content: string }>;
const dealSample = () => CATEGORIES.map((c) => pick(SEED.filter((s) => s.category === c.key)));

const NAV = [
  { id: 'how', label: 'How it plays' },
  { id: 'payoff', label: 'The payoff' },
  { id: 'journey', label: 'Journey' },
  { id: 'session', label: 'Session' },
  { id: 'cards', label: 'Cards' },
  { id: 'host', label: 'Host' },
  { id: 'rules', label: 'Rules' },
];

/** Highlights the nav link for whichever section is in view, and draws a scroll bar. */
function useSectionSpy() {
  const [active, setActive] = useState('');
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(h > 0 ? (window.scrollY / h) * 100 : 0);
      if (window.scrollY < 120) setActive('');
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    let io: IntersectionObserver | null = null;
    if ('IntersectionObserver' in window) {
      io = new IntersectionObserver(
        (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
        { rootMargin: '-45% 0px -50% 0px' },
      );
      NAV.forEach((n) => {
        const el = document.getElementById(n.id);
        if (el) io!.observe(el);
      });
    }
    return () => {
      window.removeEventListener('scroll', onScroll);
      io?.disconnect();
    };
  }, []);
  return { active, progress };
}

export function Landing() {
  const backend = useBackend();
  const { navigate } = useRouter();
  const { active, progress } = useSectionSpy();
  const [hand, setHand] = useState(() => [SEED[0], SEED[11], SEED[21], SEED[30]]);
  const [flipped, setFlipped] = useState([false, false, false, false]);
  const [dealing, setDealing] = useState(true);
  const [last, setLast] = useState<Membership | null>(null);

  useEffect(() => {
    if (backend) setLast(backend.lastMembership());
  }, [backend]);

  useEffect(() => {
    const t = window.setTimeout(() => setFlipped([true, true, true, true]), 700);
    return () => window.clearTimeout(t);
  }, []);

  function redeal() {
    setFlipped([false, false, false, false]);
    window.setTimeout(() => {
      setHand(dealSample());
      setDealing(false);
      window.requestAnimationFrame(() => setDealing(true));
      [0, 1, 2, 3].forEach((i) => window.setTimeout(() => setFlipped((f) => f.map((v, k) => (k === i ? true : v))), 420 + i * 200));
    }, 420);
  }

  return (
    <div className="shell">
      <TopBar
        links={[{ to: '/host', label: 'Host a session' }]}
        sections={
          <nav className="secnav" aria-label="Sections">
            {NAV.map((n) => (
              <a key={n.id} href={'#' + n.id} className={active === n.id ? 'on' : ''}>
                {n.label}
              </a>
            ))}
          </nav>
        }
      >
        <div className="scrollbar" style={{ width: progress + '%' }} aria-hidden="true" />
      </TopBar>
      <DemoNote />

      <header className="land-hero" id="top">
        <div className="blob a" />
        <div className="blob b" />
        <div className="blob c" />
        <div className="wrap land-grid">
          <div>
            <h1>
              <span>Same brief.</span>
              <span>Different</span>
              <span className="tw">twists.</span>
            </h1>
            <p className="lead">
              A live design game for up to 100 players. Everyone starts with the same project, then four rounds of secret
              constraint cards send every design somewhere nobody planned.
            </p>
            {last ? (
              <div className="rejoin">
                <span>
                  You are in room <b>{last.code}</b> as {last.name}.
                </span>
                <button type="button" className="btn sm" onClick={() => navigate('/play/' + last.code)}>
                  Back to the game
                </button>
              </div>
            ) : null}
            <JoinForm />
            <div className="hstats">
              <div><b>4</b><span>timed phases</span></div>
              <div><b>100</b><span>players per room</span></div>
              <div><b>5</b><span>character join code</span></div>
            </div>
          </div>
          <div>
            <div className={'hand' + (dealing ? ' dealing' : '')} aria-label="A sample hand of four constraint cards">
              {hand.map((c, i) => (
                <FlipCard
                  key={`${c.title}-${i}`}
                  category={c.category}
                  title={c.title}
                  flipped={flipped[i]}
                  frontLabel="Sealed"
                  onFlip={() => setFlipped((f) => f.map((v, k) => (k === i ? !v : v)))}
                />
              ))}
            </div>
            <div className="hand-foot">
              <p>A sample hand. Tap a card to flip it.</p>
              <button type="button" className="btn" onClick={redeal}>Deal a new hand</button>
            </div>
          </div>
        </div>
      </header>

      <Section
        id="how"
        band="tint"
        kicker="How it plays"
        title="Four steps, one surprise at a time"
        lead="Nobody plans the whole design up front. Every round hands you a new reason to rethink it."
      >
        <div className="steps4">
          <div className="step4 cat-brief"><span className="n">1</span><h3>Join with a code</h3><p>Type the 5-character room code and your name. No sign-up.</p></div>
          <div className="step4 cat-budget"><span className="n">2</span><h3>Read the shared brief</h3><p>Everyone gets the same project and a countdown to think.</p></div>
          <div className="step4 cat-space"><span className="n">3</span><h3>Flip a secret card</h3><p>Each phase deals a new constraint to your screen only.</p></div>
          <div className="step4 cat-wild"><span className="n">4</span><h3>Adapt and survive</h3><p>Rework the design for every card you hold, until the final wildcard.</p></div>
        </div>
      </Section>

      <Payoff />
      <Journey />
      <Timeline />
      <Decks />
      <HostPreview />
      <Rules />
      <UnderTheHood />
      <Retreat />

      <section className="band tint">
        <div className="wrap closer">
          <span className="kicker"><i />Ready when you are</span>
          <h2>Start a room and share the code</h2>
          <p className="lead">Hosts set up in a minute. Players need nothing but the code.</p>
          <div className="cta">
            <Link to="/host" className="btn lg">Host a session<span className="arr" aria-hidden="true">→</span></Link>
            <a href="#top" className="btn lg alt">Join a game</a>
          </div>
        </div>
      </section>

      <footer className="foot">
        <div className="wrap">
          <b>Design Twister</b> by UD IMPACT India for The Designers Retreat with HDG.
        </div>
      </footer>
    </div>
  );
}

export function JoinPage({ code }: { code?: string }) {
  return (
    <div className="shell">
      <TopBar links={[{ to: '/', label: 'Home' }]} />
      <DemoNote />
      <div className="center-msg" style={{ placeContent: 'start center', paddingTop: 48 }}>
        <div style={{ width: 'min(470px, 100%)', textAlign: 'left' }}>
          <JoinForm initialCode={code ?? ''} focusName={Boolean(code)} />
        </div>
      </div>
    </div>
  );
}
