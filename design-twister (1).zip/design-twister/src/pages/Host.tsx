import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ConfirmButton, DemoNote, Floaters, ThemeToggle, TopBar, useFloaters, useToast } from '../components/ui';
import { debounce, useBackend, useNow, useServerOffset } from '../lib/backend';
import { DEMO_MODE } from '../lib/config';
import {
  CATEGORIES, catByKey, catByPhase, errorText, formatClock, REACTIONS, remainingSeconds, stageLabel,
} from '../lib/game';
import { absoluteUrl, Link, useRouter } from '../lib/router';
import type { Backend, Card, CardDraft, Category, DealMode, HostAssignment, HostState, Participant, Session } from '../lib/types';

/* ── gate ───────────────────────────────────────────── */
export function HostGate({ children }: { children: (backend: Backend, signOut: () => void) => ReactNode }) {
  const backend = useBackend();
  const [state, setState] = useState<HostState | null>(null);

  useEffect(() => {
    if (!backend) return;
    const refresh = () => {
      backend.hostState().then(setState).catch(() => setState({ signedIn: false, isHost: false }));
    };
    refresh();
    return backend.onHostChange(refresh);
  }, [backend]);

  if (!backend || !state) {
    return (
      <div className="shell">
        <TopBar />
        <div className="center-msg"><div className="waiting"><span className="pulse" />Checking your host account…</div></div>
      </div>
    );
  }
  if (!state.signedIn) return <SignIn backend={backend} />;
  if (!state.isHost) {
    return (
      <div className="shell">
        <TopBar />
        <div className="center-msg">
          <h1>This account is not a host</h1>
          <p>You are signed in as {state.email ?? 'a player'}. Ask an admin to give this account the host role, or sign in with another account.</p>
          <button type="button" className="btn" onClick={() => void backend.hostSignOut()}>Sign out</button>
        </div>
      </div>
    );
  }
  return <>{children(backend, () => void backend.hostSignOut())}</>;
}

function SignIn({ backend }: { backend: Backend }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr('');
    try {
      await backend.hostSignIn(email, password);
    } catch (e2) {
      setErr(errorText(e2));
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="shell">
      <TopBar />
      <form className="signin panel" onSubmit={submit}>
        <h1>Host sign-in</h1>
        <p className="muted">Hosts create rooms, deal cards and run the clock. Players never need an account.</p>
        <label className="field" htmlFor="host-email">
          <span>Email</span>
          <input id="host-email" className="input" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </label>
        <label className="field" htmlFor="host-password">
          <span>Password</span>
          <input id="host-password" className="input" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        </label>
        {err ? <p className="error" role="alert">{err}</p> : null}
        <button className="btn block" type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </div>
  );
}

function HostBar({ signOut }: { signOut: () => void }) {
  return (
    <TopBar links={[{ to: '/host', label: 'Sessions' }, { to: '/host/cards', label: 'Card library' }]}>
      {!DEMO_MODE ? <button type="button" className="btn sm ghost" onClick={signOut}>Sign out</button> : null}
    </TopBar>
  );
}

/* ── sessions list ──────────────────────────────────── */
export function HostHome({ backend, signOut }: { backend: Backend; signOut: () => void }) {
  const { navigate } = useRouter();
  const toast = useToast();
  const [rows, setRows] = useState<Array<Session & { player_count: number }> | null>(null);
  const [title, setTitle] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    backend.listSessions().then(setRows).catch((e) => toast(errorText(e), true));
  }, [backend, toast]);
  useEffect(load, [load]);

  async function create(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const s = await backend.createSession(title);
      navigate('/host/s/' + s.id);
    } catch (e2) {
      toast(errorText(e2), true);
      setBusy(false);
    }
  }

  return (
    <div className="shell">
      <HostBar signOut={signOut} />
      <DemoNote />
      <main className="host-page wrap">
        <div className="host-h">
          <div>
            <h1>Sessions</h1>
            <p>Create a room, share the code, then run the game from the console.</p>
          </div>
        </div>
        <form className="card" onSubmit={create} style={{ marginBottom: 22 }}>
          <h2>New session</h2>
          <div className="newform">
            <label className="sr" htmlFor="new-title">Session name</label>
            <input id="new-title" className="input" placeholder="For example: Week 1 · Studio A" maxLength={80} value={title} onChange={(e) => setTitle(e.target.value)} />
            <button className="btn" type="submit" disabled={busy}>{busy ? 'Creating…' : 'Create room'}</button>
          </div>
        </form>
        {rows === null ? (
          <div className="waiting"><span className="pulse" />Loading sessions…</div>
        ) : rows.length === 0 ? (
          <div className="empty">
            <b>No sessions yet</b>
            <span>Create a room above. It gets a 5-character code for players to join with.</span>
          </div>
        ) : (
          <div className="slist">
            {rows.map((s) => (
              <div key={s.id} className="srow">
                <span className="code">{s.room_code}</span>
                <div className="meta">
                  <b>{s.title || 'Untitled session'}</b>
                  <small>{s.brief ? s.brief : 'No brief yet'} · {new Date(s.created_at).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}</small>
                </div>
                <span className={'pill ' + (s.stage === 'ended' ? 'over' : s.stage === 'lobby' ? 'idle' : 'live')}>
                  {stageLabel(s).split(' · ')[0]} · {s.player_count} {s.player_count === 1 ? 'player' : 'players'}
                </span>
                <div className="acts">
                  <Link to={'/host/s/' + s.id} className="btn sm">Open</Link>
                  <ConfirmButton
                    label="Delete"
                    className="btn sm alt"
                    confirmText="Delete this session and its players?"
                    onConfirm={async () => {
                      try {
                        await backend.deleteSession(s.id);
                        load();
                      } catch (e) {
                        toast(errorText(e), true);
                      }
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

/* ── live console ───────────────────────────────────── */
function useHostData(backend: Backend, id: string) {
  const toast = useToast();
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [players, setPlayers] = useState<Participant[]>([]);
  const [assign, setAssign] = useState<HostAssignment[]>([]);
  const load = useCallback(async () => {
    try {
      const [s, r] = await Promise.all([backend.getSession(id), backend.hostRoster(id)]);
      setSession(s);
      setPlayers(r.participants);
      setAssign(r.assignments);
    } catch (e) {
      toast(errorText(e), true);
    }
  }, [backend, id, toast]);
  useEffect(() => {
    void load();
    const soon = debounce(() => void load(), 300);
    const off = backend.watchSession(id, { host: true }, soon);
    const poll = window.setInterval(() => void load(), 15000);
    return () => {
      off();
      window.clearInterval(poll);
    };
  }, [backend, id, load]);
  return { session, players, assign, load };
}

export function HostSession({ backend, id, signOut }: { backend: Backend; id: string; signOut: () => void }) {
  const toast = useToast();
  const { mode } = useRouter();
  const offset = useServerOffset(backend);
  const now = useNow(250) + offset;
  const { session, players, assign, load } = useHostData(backend, id);
  const [online, setOnline] = useState<Set<string>>(new Set());
  const [floaters, addFloater] = useFloaters();
  const [tally, setTally] = useState<Record<string, number>>({});
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    const r = backend.room(id);
    const off1 = r.onReaction((e) => {
      addFloater(e);
      setTally((t) => ({ ...t, [e]: (t[e] ?? 0) + 1 }));
    });
    const off2 = r.onPresence(setOnline);
    return () => {
      off1();
      off2();
      r.close();
    };
  }, [backend, id, addFloater]);

  const run = useCallback(
    async (fn: () => Promise<void>, ok?: string) => {
      setBusy(true);
      try {
        await fn();
        await load();
        if (ok) toast(ok);
      } catch (e) {
        toast(errorText(e), true);
      } finally {
        setBusy(false);
      }
    },
    [load, toast],
  );

  if (session === undefined) {
    return (
      <div className="shell">
        <HostBar signOut={signOut} />
        <div className="center-msg"><div className="waiting"><span className="pulse" />Loading the console…</div></div>
      </div>
    );
  }
  if (session === null) {
    return (
      <div className="shell">
        <HostBar signOut={signOut} />
        <div className="center-msg">
          <h1>Session not found</h1>
          <p>It may have been deleted.</p>
          <Link to="/host" className="btn">Back to sessions</Link>
        </div>
      </div>
    );
  }

  const s = session;
  const remaining = remainingSeconds(s, now);
  const timed = s.stage === 'briefing' || s.stage === 'phase';
  const nextPhase = s.current_phase + 1;
  const nextCat = nextPhase <= 4 ? catByPhase(nextPhase) : null;
  const previewRows = nextCat ? assign.filter((a) => a.category === nextCat.key && !a.revealed) : [];
  const onlineCount = players.filter((p) => online.has(p.id)).length;
  const joinUrl = absoluteUrl(mode, '/join/' + s.room_code);

  let primary: { label: string; action: () => Promise<void>; confirm?: string; disabled?: boolean; ok: string } | null = null;
  if (s.stage === 'lobby') {
    primary = {
      label: 'Start briefing',
      action: () => backend.startBriefing(s.id),
      confirm: players.length === 0 ? 'No players have joined yet. Start anyway?' : undefined,
      disabled: !s.brief.trim(),
      ok: 'Briefing started',
    };
  } else if (timed && s.current_phase < 4) {
    primary = {
      label: `Deal Phase ${nextPhase}`,
      action: () => backend.dealPhase(s.id),
      confirm: remaining && remaining > 0 ? `${s.stage === 'briefing' ? 'The briefing' : `Phase ${s.current_phase}`} still has ${formatClock(remaining)} left. Deal now?` : undefined,
      ok: `Phase ${nextPhase} dealt`,
    };
  } else if (s.stage === 'phase' && s.current_phase === 4) {
    primary = { label: 'End session', action: () => backend.endSession(s.id), confirm: 'End the session for everyone?', ok: 'Session ended' };
  }

  const rail = [
    { key: 'lobby', label: 'Lobby', cls: '', done: s.stage !== 'lobby', now: s.stage === 'lobby', pre: true },
    { key: 'briefing', label: 'Briefing', cls: '', done: s.stage === 'phase' || s.stage === 'ended', now: s.stage === 'briefing', pre: true },
    ...CATEGORIES.map((c) => ({
      key: c.key,
      label: `${c.phase} · ${c.short}`,
      cls: c.cls,
      done: s.stage === 'ended' || (s.stage === 'phase' && s.current_phase > c.phase),
      now: s.stage === 'phase' && s.current_phase === c.phase,
      pre: false,
    })),
  ];

  const shownPlayers = filter.trim() ? players.filter((p) => p.name.toLowerCase().includes(filter.trim().toLowerCase())) : players;
  const cell = (pid: string, cat: Category) => {
    const a = assign.find((x) => x.participant_id === pid && x.category === cat);
    const c = catByKey(cat);
    if (!a) return <span className="tg none">–</span>;
    if (a.revealed) return <span className={'tg ' + c.cls} title={a.title}>{a.title}</span>;
    return (
      <span className="cellflex">
        <span className={'tg preview ' + c.cls} title={'Preview: ' + a.title}>{a.title}</span>
        <button type="button" className="iconbtn" disabled={busy} onClick={() => void run(() => backend.reroll(s.id, pid))} aria-label={'Reroll preview card'} title="Reroll this card">
          ↻
        </button>
      </span>
    );
  };

  return (
    <div className="shell">
      <HostBar signOut={signOut} />
      <DemoNote />
      <div className="ctl">
        <div className="wrap ctl-in">
          <div className="roomcode">
            <small>Room code</small>
            <b>{s.room_code}</b>
          </div>
          <span className={'pill ' + (s.paused ? 'paused' : s.stage === 'ended' ? 'over' : s.stage === 'lobby' ? 'idle' : 'live')}>
            {s.paused ? 'Paused' : stageLabel(s)}
          </span>
          <span className="spacer" />
          {timed ? (
            <>
              <span className={'clock' + (!s.paused && remaining !== null && remaining <= 30 && remaining > 0 ? ' low' : '')} role="timer">{formatClock(remaining)}</span>
              <div className="tools">
                {s.paused ? (
                  <button type="button" className="btn sm alt" disabled={busy} onClick={() => void run(() => backend.resume(s.id), 'Resumed')}>Resume</button>
                ) : (
                  <button type="button" className="btn sm alt" disabled={busy} onClick={() => void run(() => backend.pause(s.id), 'Paused')}>Pause</button>
                )}
                <button type="button" className="btn sm alt" disabled={busy} onClick={() => void run(() => backend.addTime(s.id, 60), 'Added 1 minute')}>+1 min</button>
                <button type="button" className="btn sm alt" disabled={busy} onClick={() => void run(() => backend.addTime(s.id, 300), 'Added 5 minutes')}>+5 min</button>
              </div>
            </>
          ) : null}
          {primary ? (
            <ConfirmButton
              label={primary.label}
              className="btn"
              disabled={busy || primary.disabled}
              needsConfirm={Boolean(primary.confirm)}
              confirmText={primary.confirm ?? ''}
              onConfirm={() => run(primary!.action, primary!.ok)}
            />
          ) : s.stage === 'ended' ? (
            <span className="pill over">Session ended</span>
          ) : null}
        </div>
      </div>

      <main className="host-page wrap" style={{ paddingTop: 0 }}>
        <div className="rail" aria-label="Session progress">
          {rail.map((r) => (
            <span key={r.key} className={`${r.cls}${r.done ? ' done' : ''}${r.now ? ' now' : ''}${r.pre ? ' pre' : ''}`}>{r.label}</span>
          ))}
        </div>

        <div className="console">
          <aside className="side">
            <div className="card joinbig">
              <div className="card-h">
                <h2>Players join with</h2>
                <Link to={`/host/s/${s.id}/stage`} className="btn sm alt">Screen-share view</Link>
              </div>
              <span className="codeline">{s.room_code}</span>
              {joinUrl ? (
                <>
                  <span className="url">{joinUrl}</span>
                  <button type="button" className="btn sm alt" onClick={() => copy(joinUrl, toast)}>Copy join link</button>
                </>
              ) : (
                <span className="note">Players open the game, type this code and their name.</span>
              )}
            </div>
            <SetupCard backend={backend} session={s} run={run} busy={busy} />
            <div className="card">
              <div className="card-h">
                <h2>Room reactions</h2>
              </div>
              <div className="reactstats">
                {REACTIONS.map((e) => (
                  <span key={e}>{e} <b className="num">{tally[e] ?? 0}</b></span>
                ))}
              </div>
            </div>
            {s.stage !== 'ended' && s.stage !== 'lobby' ? (
              <ConfirmButton label="End session now" className="btn alt" confirmText="End the session for everyone?" onConfirm={() => run(() => backend.endSession(s.id), 'Session ended')} disabled={busy} />
            ) : null}
          </aside>

          <section className="main-col">
            <div className="card">
              <div className="card-h">
                <h2>
                  Players <span className="muted num">· {players.length} joined · {onlineCount} online</span>
                </h2>
                {players.length > 8 ? (
                  <input className="input" style={{ maxWidth: 220, padding: '7px 11px', fontSize: '.9rem' }} placeholder="Find a player" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Find a player" />
                ) : null}
              </div>
              {nextCat && s.stage !== 'lobby' && s.stage !== 'ended' ? (
                <div className="preview-bar">
                  <span>
                    <b>Next deal: Phase {nextPhase} · {nextCat.label}.</b>{' '}
                    <span className="muted">{previewRows.length} of {players.length} previews ready. Players cannot see these yet.</span>
                  </span>
                  <button type="button" className="btn sm alt" disabled={busy || players.length === 0} onClick={() => void run(() => backend.reshuffle(s.id), 'Previews reshuffled')}>Reshuffle all</button>
                </div>
              ) : s.stage === 'lobby' ? (
                <p className="note">Card previews for Phase 1 appear here when the briefing starts. You can reroll any player before you deal.</p>
              ) : null}
              {players.length === 0 ? (
                <div className="empty">
                  <b>Waiting for players</b>
                  <span>Share the room code {s.room_code}. Names appear here as people join.</span>
                </div>
              ) : (
                <div className="tablewrap">
                  <table className="ptable">
                    <thead>
                      <tr>
                        <th>Player</th>
                        {CATEGORIES.map((c) => <th key={c.key}>{c.phase} · {c.short}</th>)}
                        <th><span className="sr">Remove</span></th>
                      </tr>
                    </thead>
                    <tbody>
                      {shownPlayers.map((p) => (
                        <tr key={p.id}>
                          <td>
                            <span className="pname">
                              <span className={'dot ' + (online.has(p.id) ? 'on' : 'off')} title={online.has(p.id) ? 'Online' : 'Not connected'} />
                              <span title={p.name}>{p.name}</span>
                            </span>
                          </td>
                          {CATEGORIES.map((c) => <td key={c.key}>{cell(p.id, c.key)}</td>)}
                          <td>
                            <RemoveButton onRemove={() => run(() => backend.removePlayer(p.id), `${p.name} removed`)} disabled={busy} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </section>
        </div>
      </main>
      <Floaters items={floaters} />
    </div>
  );
}

function RemoveButton({ onRemove, disabled }: { onRemove: () => void; disabled?: boolean }) {
  const [ask, setAsk] = useState(false);
  useEffect(() => {
    if (!ask) return;
    const t = window.setTimeout(() => setAsk(false), 5000);
    return () => window.clearTimeout(t);
  }, [ask]);
  return ask ? (
    <button type="button" className="iconbtn del" onClick={() => { setAsk(false); onRemove(); }} disabled={disabled}>Remove?</button>
  ) : (
    <button type="button" className="iconbtn" onClick={() => setAsk(true)} disabled={disabled} aria-label="Remove player" title="Remove player">✕</button>
  );
}

function copy(text: string, toast: (t: string, bad?: boolean) => void) {
  try {
    void navigator.clipboard.writeText(text).then(
      () => toast('Join link copied'),
      () => toast('Copy did not work. Select the link and copy it.', true),
    );
  } catch {
    toast('Copy did not work. Select the link and copy it.', true);
  }
}

function SetupCard({ backend, session: s, run, busy }: { backend: Backend; session: Session; run: (fn: () => Promise<void>, ok?: string) => Promise<void>; busy: boolean }) {
  const [title, setTitle] = useState(s.title);
  const [brief, setBrief] = useState(s.brief);
  const [bMin, setBMin] = useState(String(Math.round(s.briefing_seconds / 60)));
  const [pMin, setPMin] = useState(String(Math.round(s.phase_seconds / 60)));
  const dirtyBrief = brief !== s.brief;
  const locked = s.stage !== 'lobby';
  const lastId = useRef(s.id);

  useEffect(() => {
    if (lastId.current !== s.id || !dirtyBrief) setBrief(s.brief);
    lastId.current = s.id;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.id, s.brief]);
  useEffect(() => setTitle(s.title), [s.title]);
  useEffect(() => setBMin(String(Math.round(s.briefing_seconds / 60))), [s.briefing_seconds]);
  useEffect(() => setPMin(String(Math.round(s.phase_seconds / 60))), [s.phase_seconds]);

  const saveMinutes = (field: 'briefing_seconds' | 'phase_seconds', raw: string, max: number) => {
    const n = Math.round(Number(raw));
    if (!Number.isFinite(n) || n < 1 || n > max) return;
    if (n * 60 === s[field]) return;
    void run(() => backend.updateSession(s.id, { [field]: n * 60 }), 'Timer saved');
  };

  return (
    <div className="card">
      <div className="card-h">
        <h2>Session setup</h2>
        <span className="savestate">{locked ? 'Brief locked' : dirtyBrief ? 'Unsaved brief' : 'Saved'}</span>
      </div>
      <label className="field" htmlFor="s-title">
        <span>Session name</span>
        <input id="s-title" className="input" maxLength={80} value={title} onChange={(e) => setTitle(e.target.value)} onBlur={() => title !== s.title && void run(() => backend.updateSession(s.id, { title }))} placeholder="Week 1 · Studio A" />
      </label>
      <label className="field" htmlFor="s-brief">
        <span>Project brief</span>
        <textarea
          id="s-brief"
          className="textarea"
          maxLength={2000}
          value={brief}
          readOnly={locked}
          onChange={(e) => setBrief(e.target.value)}
          onBlur={() => dirtyBrief && !locked && void run(() => backend.updateSession(s.id, { brief }), 'Brief saved')}
          placeholder="Design a co-working lounge for a Korean fintech team in Gurugram."
        />
        <small>{locked ? 'Locked once the briefing starts, so every player reads the same brief.' : 'Everyone sees this brief. You need one before you can start.'}</small>
      </label>
      {!locked && dirtyBrief ? (
        <button type="button" className="btn sm" disabled={busy} onClick={() => void run(() => backend.updateSession(s.id, { brief }), 'Brief saved')}>Save brief</button>
      ) : null}
      <div className="row2">
        <label className="field" htmlFor="s-bmin">
          <span>Briefing, minutes</span>
          <input id="s-bmin" className="input num" type="number" min={1} max={60} value={bMin} onChange={(e) => setBMin(e.target.value)} onBlur={() => saveMinutes('briefing_seconds', bMin, 60)} disabled={s.stage !== 'lobby'} />
        </label>
        <label className="field" htmlFor="s-pmin">
          <span>Each phase, minutes</span>
          <input id="s-pmin" className="input num" type="number" min={1} max={120} value={pMin} onChange={(e) => setPMin(e.target.value)} onBlur={() => saveMinutes('phase_seconds', pMin, 120)} disabled={s.stage === 'ended'} />
        </label>
      </div>
      <div className="field">
        <span>Dealing</span>
        <div className="seg" role="group" aria-label="Dealing mode">
          {(['balanced', 'random'] as DealMode[]).map((d) => (
            <button key={d} type="button" aria-pressed={s.distribution_mode === d} disabled={busy || s.stage === 'ended'} onClick={() => s.distribution_mode !== d && void run(() => backend.updateSession(s.id, { distribution_mode: d }), d === 'balanced' ? 'Balanced dealing' : 'Random dealing')}>
              {d === 'balanced' ? 'Balanced' : 'Random'}
            </button>
          ))}
        </div>
        <small>{s.distribution_mode === 'balanced' ? 'Every card is used once before any card repeats.' : 'Unique cards while they last, then any card at random.'} Applies to the next previews; use Reshuffle all to redo the current ones.</small>
      </div>
    </div>
  );
}

/* ── screen-share view ──────────────────────────────── */
export function HostStage({ backend, id }: { backend: Backend; id: string }) {
  const { mode } = useRouter();
  const offset = useServerOffset(backend);
  const now = useNow(250) + offset;
  const { session, players } = useHostData(backend, id);
  const [floaters, addFloater] = useFloaters();
  const [online, setOnline] = useState<Set<string>>(new Set());
  useEffect(() => {
    const r = backend.room(id);
    const a = r.onReaction(addFloater);
    const b = r.onPresence(setOnline);
    return () => {
      a();
      b();
      r.close();
    };
  }, [backend, id, addFloater]);

  if (!session) {
    return <div className="shell"><div className="center-msg"><div className="waiting"><span className="pulse" />Loading…</div></div></div>;
  }
  const s = session;
  const remaining = remainingSeconds(s, now);
  const cat = s.stage === 'phase' ? catByPhase(s.current_phase) : null;
  const joinUrl = absoluteUrl(mode, '/join');
  const onlineCount = players.filter((p) => online.has(p.id)).length;

  return (
    <div className="stage">
      <div className="blob a" />
      <div className="blob b" />
      <div className="stage-top">
        <span className="logo"><i aria-hidden="true" />Design Twister</span>
        <span className="spacer" />
        {s.paused ? <span className="pill paused">Paused</span> : null}
        <span className="chip">Room {s.room_code}</span>
        <ThemeToggle small />
        <Link to={'/host/s/' + s.id} className="btn sm alt">Back to console</Link>
      </div>
      <div className="stage-mid">
        {s.stage === 'lobby' ? (
          <>
            <p className="eyebrow">Join the game{joinUrl ? ' at ' + joinUrl.replace(/^https?:\/\//, '') : ''}</p>
            <span className="bigcode">{s.room_code}</span>
            <h1>{players.length} {players.length === 1 ? 'player is' : 'players are'} in</h1>
          </>
        ) : s.stage === 'briefing' ? (
          <>
            <p className="eyebrow">The project brief</p>
            <div className="brief">{s.brief}</div>
            <span className={'bigtimer' + (remaining !== null && remaining <= 30 && remaining > 0 ? ' low' : '')}>{formatClock(remaining)}</span>
          </>
        ) : s.stage === 'phase' && cat ? (
          <>
            <span className={'phasecard blueprint ' + cat.cls}>Phase {s.current_phase} · {cat.label}</span>
            <span className={'bigtimer' + (remaining !== null && remaining <= 30 && remaining > 0 ? ' low' : '')}>{formatClock(remaining)}</span>
            <h1 style={{ fontSize: 'clamp(1.2rem, 2.6vw, 2rem)' }}>{remaining === 0 ? 'Time is up. Pens down.' : 'Everyone has a new secret card. Adapt your design.'}</h1>
          </>
        ) : (
          <>
            <h1>That is a wrap</h1>
            <p className="eyebrow">Same brief. Different twists. Time to compare.</p>
          </>
        )}
      </div>
      <div className="stage-foot">
        <span>{players.length} joined · {onlineCount} online</span>
        <span>Same brief. Different twists.</span>
      </div>
      <Floaters items={floaters} />
    </div>
  );
}

/* ── card library ───────────────────────────────────── */
const EMPTY: CardDraft = { category: 'design_brief', title: '', content: '', enabled: true };

export function CardLibrary({ backend, signOut }: { backend: Backend; signOut: () => void }) {
  const toast = useToast();
  const [cards, setCards] = useState<Card[] | null>(null);
  const [tab, setTab] = useState<Category>('design_brief');
  const [draft, setDraft] = useState<CardDraft | null>(null);
  const [busy, setBusy] = useState(false);
  const editorRef = useRef<HTMLFormElement>(null);

  const load = useCallback(() => {
    backend.listCards().then(setCards).catch((e) => toast(errorText(e), true));
  }, [backend, toast]);
  useEffect(load, [load]);
  useEffect(() => {
    if (draft) editorRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, [draft?.id, draft === null]); // eslint-disable-line react-hooks/exhaustive-deps

  const counts = useMemo(() => {
    const out: Record<string, { on: number; all: number }> = {};
    CATEGORIES.forEach((c) => (out[c.key] = { on: 0, all: 0 }));
    cards?.forEach((c) => {
      out[c.category].all++;
      if (c.enabled) out[c.category].on++;
    });
    return out;
  }, [cards]);

  async function act(fn: () => Promise<void>, ok?: string) {
    setBusy(true);
    try {
      await fn();
      load();
      if (ok) toast(ok);
    } catch (e) {
      toast(errorText(e), true);
    } finally {
      setBusy(false);
    }
  }

  async function save(e: FormEvent) {
    e.preventDefault();
    if (!draft) return;
    const d = draft;
    await act(async () => {
      await backend.saveCard(d);
      setDraft(null);
      setTab(d.category);
    }, d.id ? 'Card updated' : 'Card added');
  }

  const meta = catByKey(tab);
  const list = (cards ?? []).filter((c) => c.category === tab);

  return (
    <div className="shell">
      <HostBar signOut={signOut} />
      <DemoNote />
      <main className="host-page wrap">
        <div className="host-h">
          <div>
            <h1>Card library</h1>
            <p>Switched-off cards stay in the library but are never dealt.</p>
          </div>
          <button type="button" className="btn" onClick={() => setDraft({ ...EMPTY, category: tab })}>Add a card</button>
        </div>

        {draft ? (
          <form ref={editorRef} className={'card editor ' + catByKey(draft.category).cls} onSubmit={save} style={{ marginBottom: 22, borderTop: '8px solid var(--c)' }}>
            <h2>{draft.id ? 'Edit card' : 'New card'}</h2>
            <div className="field">
              <span>Category</span>
              <div className="seg" role="group" aria-label="Category" style={{ flexWrap: 'wrap', borderRadius: 18 }}>
                {CATEGORIES.map((c) => (
                  <button key={c.key} type="button" aria-pressed={draft.category === c.key} onClick={() => setDraft({ ...draft, category: c.key })}>
                    {c.phase} · {c.label}
                  </button>
                ))}
              </div>
            </div>
            <label className="field" htmlFor="card-title">
              <span>Title</span>
              <input id="card-title" className="input" maxLength={120} value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} placeholder="A library for ghosts" required autoFocus />
            </label>
            <label className="field" htmlFor="card-content">
              <span>Description</span>
              <textarea id="card-content" className="textarea" style={{ minHeight: 90 }} maxLength={600} value={draft.content} onChange={(e) => setDraft({ ...draft, content: e.target.value })} placeholder="One or two sentences that make the constraint concrete." />
            </label>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
              <button type="submit" className="btn" disabled={busy || !draft.title.trim()}>{draft.id ? 'Save changes' : 'Add card'}</button>
              <button type="button" className="btn alt" onClick={() => setDraft(null)}>Cancel</button>
            </div>
          </form>
        ) : null}

        <div className="tabs" role="group" aria-label="Card category">
          {CATEGORIES.map((c) => (
            <button key={c.key} type="button" className={c.cls} aria-pressed={tab === c.key} onClick={() => setTab(c.key)}>
              {c.phase} · {c.label} <small className="num">{counts[c.key].on}/{counts[c.key].all}</small>
            </button>
          ))}
        </div>
        {cards === null ? (
          <div className="waiting"><span className="pulse" />Loading cards…</div>
        ) : list.length === 0 ? (
          <div className="empty">
            <b>No {meta.label} cards yet</b>
            <span>Phase {meta.phase} cannot be dealt until this category has at least one switched-on card.</span>
            <button type="button" className="btn sm" onClick={() => setDraft({ ...EMPTY, category: tab })}>Add a card</button>
          </div>
        ) : (
          <>
            {counts[tab].on === 0 ? <p className="note" style={{ marginBottom: 14 }}><b>Every card here is switched off.</b> Phase {meta.phase} cannot be dealt until one is on.</p> : null}
            <div className="cards-grid">
              {list.map((c) => (
                <div key={c.id} className={'libcard ' + meta.cls + (c.enabled ? '' : ' off')}>
                  <b>{c.title}</b>
                  {c.content ? <p>{c.content}</p> : null}
                  <div className="acts">
                    <button type="button" className="switch" role="switch" aria-checked={c.enabled} disabled={busy} onClick={() => void act(() => backend.setCardEnabled(c.id, !c.enabled))}>
                      <i />
                      {c.enabled ? 'On' : 'Off'}
                    </button>
                    <span className="spacer" />
                    <button type="button" className="iconbtn" onClick={() => setDraft({ id: c.id, category: c.category, title: c.title, content: c.content, enabled: c.enabled })}>Edit</button>
                    <ConfirmButton label="Delete" className="iconbtn del" confirmText="Delete?" onConfirm={() => act(() => backend.deleteCard(c.id), 'Card deleted')} disabled={busy} />
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </main>
    </div>
  );
}
