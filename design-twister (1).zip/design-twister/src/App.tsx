import { ToastProvider } from './components/ui';
import { ROUTER_MODE } from './lib/config';
import { match, Router, useRouter, Link } from './lib/router';
import { JoinPage, Landing } from './pages/Landing';
import { Play } from './pages/Play';
import { CardLibrary, HostGate, HostHome, HostSession, HostStage } from './pages/Host';

function Routes() {
  const { path } = useRouter();
  let m: Record<string, string> | null;

  if (path === '/' || path === '') return <Landing />;
  if ((m = match('/join/:code', path))) return <JoinPage code={m.code.toUpperCase()} />;
  if (match('/join', path)) return <JoinPage />;
  if ((m = match('/play/:code', path))) return <Play key={m.code} code={m.code.toUpperCase()} />;
  if (match('/host', path)) return <HostGate>{(b, out) => <HostHome backend={b} signOut={out} />}</HostGate>;
  if (match('/host/cards', path)) return <HostGate>{(b, out) => <CardLibrary backend={b} signOut={out} />}</HostGate>;
  if ((m = match('/host/s/:id/stage', path))) {
    const id = m.id;
    return <HostGate>{(b) => <HostStage backend={b} id={id} />}</HostGate>;
  }
  if ((m = match('/host/s/:id', path))) {
    const id = m.id;
    return <HostGate>{(b, out) => <HostSession key={id} backend={b} id={id} signOut={out} />}</HostGate>;
  }
  return (
    <div className="shell">
      <div className="center-msg">
        <h1>This page does not exist</h1>
        <p>Check the link, or start from the home page.</p>
        <Link to="/" className="btn">Go to the start</Link>
      </div>
    </div>
  );
}

export function App() {
  return (
    <Router mode={ROUTER_MODE}>
      <ToastProvider>
        <Routes />
      </ToastProvider>
    </Router>
  );
}
