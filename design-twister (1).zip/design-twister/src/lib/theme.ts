import { useCallback, useEffect, useState } from 'react';

export type Theme = 'light' | 'dark';
const KEY = 'dt-theme';

function systemTheme(): Theme {
  try {
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  } catch {
    return 'light';
  }
}

function current(): Theme {
  const t = document.documentElement.getAttribute('data-theme');
  return t === 'dark' || t === 'light' ? t : systemTheme();
}

/** Applies the player's saved Day or Night choice, or follows the device until they pick one. */
export function applySavedTheme(): void {
  try {
    const saved = localStorage.getItem(KEY);
    if (saved === 'dark' || saved === 'light') document.documentElement.setAttribute('data-theme', saved);
  } catch {
    /* storage blocked: follow the device */
  }
}

export function useTheme(): [Theme, (t: Theme) => void] {
  const [theme, setThemeState] = useState<Theme>(current);
  useEffect(() => {
    const sync = () => setThemeState(current());
    let mq: MediaQueryList | null = null;
    try {
      mq = window.matchMedia('(prefers-color-scheme: dark)');
      mq.addEventListener('change', sync);
    } catch {
      mq = null;
    }
    const obs = new MutationObserver(sync);
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    window.addEventListener('dt-theme', sync);
    return () => {
      mq?.removeEventListener('change', sync);
      obs.disconnect();
      window.removeEventListener('dt-theme', sync);
    };
  }, []);
  const setTheme = useCallback((t: Theme) => {
    document.documentElement.setAttribute('data-theme', t);
    try {
      localStorage.setItem(KEY, t);
    } catch {
      /* storage blocked */
    }
    window.dispatchEvent(new Event('dt-theme'));
  }, []);
  return [theme, setTheme];
}
