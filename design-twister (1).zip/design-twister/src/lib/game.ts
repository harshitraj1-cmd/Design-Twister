import type { Category, Session } from './types';

export interface CategoryMeta {
  key: Category;
  phase: number;
  cls: string;
  label: string;
  short: string;
  hint: string;
}

export const CATEGORIES: CategoryMeta[] = [
  { key: 'design_brief', phase: 1, cls: 'cat-brief', label: 'Design Brief', short: 'Brief', hint: 'Your persona and challenge' },
  { key: 'budget_material', phase: 2, cls: 'cat-budget', label: 'Budget & Material', short: 'Budget', hint: 'What you can spend and use' },
  { key: 'spatial_rules', phase: 3, cls: 'cat-space', label: 'Spatial Rules', short: 'Spatial', hint: 'How the space behaves' },
  { key: 'wildcard', phase: 4, cls: 'cat-wild', label: 'Wildcard', short: 'Wildcard', hint: 'The late shock' },
];

export const catByKey = (k: Category): CategoryMeta => CATEGORIES.find((c) => c.key === k) ?? CATEGORIES[0];
export const catByPhase = (p: number): CategoryMeta => CATEGORIES[Math.min(Math.max(p, 1), 4) - 1];

export const ROOM_CODE_LENGTH = 5;
export const REACTIONS = ['💡', '😱', '🔥', '⏱️', '🤯'];

export function cleanCode(raw: string): string {
  return raw.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, ROOM_CODE_LENGTH);
}

/** Seconds left on the current countdown, or null when no countdown is running. */
export function remainingSeconds(s: Session, nowMs: number): number | null {
  if (s.stage === 'lobby' || s.stage === 'ended') return null;
  if (s.paused) return Math.max(0, s.paused_remaining_seconds ?? 0);
  if (!s.ends_at) return null;
  return Math.max(0, Math.ceil((Date.parse(s.ends_at) - nowMs) / 1000));
}

export function formatClock(secs: number | null): string {
  if (secs === null) return '--:--';
  const m = Math.floor(secs / 60);
  const s = secs % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function stageLabel(s: Session): string {
  if (s.stage === 'lobby') return 'Lobby';
  if (s.stage === 'briefing') return 'Briefing';
  if (s.stage === 'ended') return 'Ended';
  return `Phase ${s.current_phase} · ${catByPhase(s.current_phase).label}`;
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function shuffle<T>(a: T[]): T[] {
  const b = a.slice();
  for (let i = b.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [b[i], b[j]] = [b[j], b[i]];
  }
  return b;
}

export function uuid(): string {
  try {
    if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  } catch {
    /* fall through */
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

export function errorText(e: unknown): string {
  if (e instanceof Error && e.message) return e.message;
  if (typeof e === 'object' && e && 'message' in e) return String((e as { message: unknown }).message);
  return 'Something went wrong. Try again.';
}
