// Build-time settings. Vite fills import.meta.env from .env files.
const env: Record<string, string | undefined> =
  ((import.meta as unknown as { env?: Record<string, string | undefined> }).env) ?? {};

export const SUPABASE_URL = env.VITE_SUPABASE_URL ?? '';
export const SUPABASE_ANON_KEY = env.VITE_SUPABASE_ANON_KEY ?? '';

/** Demo mode keeps everything in this browser. It is on when no Supabase project is configured. */
export const DEMO_MODE = env.VITE_DEMO === '1' || !SUPABASE_URL || !SUPABASE_ANON_KEY;

/** browser: clean paths like /join/K7P2Q. hash: #/join/K7P2Q. memory: no URL changes (embedded demos). */
export const ROUTER_MODE: 'browser' | 'hash' | 'memory' =
  env.VITE_ROUTER === 'hash' ? 'hash' : env.VITE_ROUTER === 'memory' ? 'memory' : 'browser';
