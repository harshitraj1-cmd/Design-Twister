// Demo backend: the whole game runs inside this browser.
// Every tab is a different player; tabs share state through localStorage and BroadcastChannel.
// It mirrors the rules in supabase/migrations so the demo plays exactly like the live game.
import seed from './seedCards.json';
import { shuffle, uuid } from './game';
import type {
  Assignment, Backend, Card, CardDraft, Category, HandCard, HostAssignment, HostState,
  Membership, Participant, Room, Session, SessionPatch,
} from './types';

interface StoredParticipant extends Participant {
  auth_user_id: string;
}
interface DB {
  v: 1;
  cards: Card[];
  sessions: Session[];
  participants: StoredParticipant[];
  assignments: Assignment[];
}

const KEY = 'dt-demo-db-v1';
const PHASE_CATS: Category[] = ['design_brief', 'budget_material', 'spatial_rules', 'wildcard'];
const CAT_LABEL: Record<Category, string> = {
  design_brief: 'Design Brief',
  budget_material: 'Budget & Material',
  spatial_rules: 'Spatial Rules',
  wildcard: 'Wildcard',
};
const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

let memoryDb: DB | null = null;
let memoryUid: string | null = null;
const memoryMembers = new Map<string, string>();
const listeners = new Set<() => void>();

function now(): string {
  return new Date().toISOString();
}

function seededDb(): DB {
  const t = Date.now();
  return {
    v: 1,
    cards: (seed as Array<{ category: Category; title: string; content: string }>).map((c, i) => ({
      id: uuid(),
      category: c.category,
      title: c.title,
      content: c.content,
      enabled: true,
      created_at: new Date(t + i).toISOString(),
    })),
    sessions: [],
    participants: [],
    assignments: [],
  };
}

function load(): DB {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as DB;
      if (parsed && parsed.v === 1) return parsed;
    }
  } catch {
    if (memoryDb) return memoryDb;
  }
  if (memoryDb) return memoryDb;
  const db = seededDb();
  save(db, false);
  return db;
}

function save(db: DB, notify = true): void {
  memoryDb = db;
  try {
    localStorage.setItem(KEY, JSON.stringify(db));
  } catch {
    /* storage blocked: this tab keeps playing from memory */
  }
  if (notify) listeners.forEach((fn) => fn());
}

function mutate<T>(fn: (db: DB) => T): T {
  const db = load();
  const out = fn(db);
  save(db);
  return out;
}

try {
  window.addEventListener('storage', (e) => {
    if (e.key === KEY) {
      memoryDb = null;
      listeners.forEach((fn) => fn());
    }
  });
} catch {
  /* no window */
}

function uid(): string {
  try {
    let id = sessionStorage.getItem('dt-demo-uid');
    if (!id) {
      id = uuid();
      sessionStorage.setItem('dt-demo-uid', id);
    }
    return id;
  } catch {
    if (!memoryUid) memoryUid = uuid();
    return memoryUid;
  }
}

function fail(msg: string): never {
  throw new Error(msg);
}

function findSession(db: DB, id: string): Session {
  return db.sessions.find((s) => s.id === id) ?? fail('Session not found.');
}

function addSeconds(iso: string | null, secs: number): string {
  const base = Math.max(iso ? Date.parse(iso) : Date.now(), Date.now());
  return new Date(base + secs * 1000).toISOString();
}

function pickCard(db: DB, sid: string, cat: Category, mode: string, exclude?: string): string | null {
  const pool = db.cards.filter((c) => c.enabled && c.category === cat && c.id !== exclude);
  if (pool.length === 0) return exclude ?? null;
  const used = (id: string) => db.assignments.filter((a) => a.session_id === sid && a.card_id === id).length;
  const scored = shuffle(pool).map((c) => ({ id: c.id, n: used(c.id) }));
  if (mode === 'random') {
    const fresh = scored.filter((c) => c.n === 0);
    return (fresh[0] ?? scored[0]).id;
  }
  scored.sort((a, b) => a.n - b.n);
  return scored[0].id;
}

function preparePreview(db: DB, sid: string): void {
  const s = findSession(db, sid);
  if (s.stage === 'ended' || s.current_phase >= 4) return;
  const cat = PHASE_CATS[s.current_phase];
  const players = db.participants
    .filter((p) => p.session_id === sid)
    .sort((a, b) => a.joined_at.localeCompare(b.joined_at));
  for (const p of players) {
    if (db.assignments.some((a) => a.participant_id === p.id && a.category === cat)) continue;
    const cid = pickCard(db, sid, cat, s.distribution_mode);
    if (!cid) fail(`There are no switched-on ${CAT_LABEL[cat]} cards. Add or switch on cards in the card library.`);
    db.assignments.push({ id: uuid(), session_id: sid, participant_id: p.id, card_id: cid, category: cat, revealed: false });
  }
}

function membersKey(code: string) {
  return 'dt-demo-member-' + code;
}

function readMember(code: string): Membership | null {
  try {
    const raw = sessionStorage.getItem(membersKey(code));
    return raw ? (JSON.parse(raw) as Membership) : null;
  } catch {
    const raw = memoryMembers.get(code);
    return raw ? (JSON.parse(raw) as Membership) : null;
  }
}

function writeMember(m: Membership): void {
  const raw = JSON.stringify(m);
  try {
    sessionStorage.setItem(membersKey(m.code), raw);
    sessionStorage.setItem('dt-demo-last-member', raw);
  } catch {
    memoryMembers.set(m.code, raw);
    memoryMembers.set('__last', raw);
  }
}

class DemoRoom implements Room {
  private ch: BroadcastChannel | null = null;
  private reactionCbs = new Set<(e: string) => void>();
  private presenceCbs = new Set<(ids: Set<string>) => void>();
  private seen = new Map<string, number>();
  private me: string | null = null;
  private timers: number[] = [];

  constructor(sessionId: string) {
    try {
      this.ch = new BroadcastChannel('dt-demo-room-' + sessionId);
      this.ch.onmessage = (ev: MessageEvent) => this.handle(ev.data);
    } catch {
      this.ch = null;
    }
    this.timers.push(window.setInterval(() => this.emitPresence(), 2000));
  }

  private handle(msg: { t: string; emoji?: string; pid?: string }) {
    if (msg.t === 'react' && msg.emoji) this.reactionCbs.forEach((cb) => cb(msg.emoji as string));
    if (msg.t === 'here' && msg.pid) {
      this.seen.set(msg.pid, Date.now());
      this.emitPresence();
    }
    if (msg.t === 'bye' && msg.pid) {
      this.seen.delete(msg.pid);
      this.emitPresence();
    }
    if (msg.t === 'who' && this.me) this.post({ t: 'here', pid: this.me });
  }

  private post(msg: object) {
    try {
      this.ch?.postMessage(msg);
    } catch {
      /* closed */
    }
  }

  private emitPresence() {
    const cutoff = Date.now() - 7000;
    const ids = new Set<string>();
    this.seen.forEach((t, pid) => {
      if (t >= cutoff) ids.add(pid);
    });
    if (this.me) ids.add(this.me);
    this.presenceCbs.forEach((cb) => cb(ids));
  }

  send(emoji: string) {
    this.post({ t: 'react', emoji });
    this.reactionCbs.forEach((cb) => cb(emoji));
  }
  onReaction(cb: (e: string) => void) {
    this.reactionCbs.add(cb);
    return () => this.reactionCbs.delete(cb);
  }
  track(pid: string) {
    this.me = pid;
    this.post({ t: 'here', pid });
    this.timers.push(window.setInterval(() => this.post({ t: 'here', pid }), 3000));
  }
  onPresence(cb: (ids: Set<string>) => void) {
    this.presenceCbs.add(cb);
    this.post({ t: 'who' });
    this.emitPresence();
    return () => this.presenceCbs.delete(cb);
  }
  close() {
    if (this.me) this.post({ t: 'bye', pid: this.me });
    this.timers.forEach((t) => clearInterval(t));
    this.reactionCbs.clear();
    this.presenceCbs.clear();
    try {
      this.ch?.close();
    } catch {
      /* already closed */
    }
  }
}

const strip = ({ auth_user_id: _a, ...p }: StoredParticipant): Participant => p;

export function createDemoBackend(): Backend {
  return {
    mode: 'demo',

    async serverOffset() {
      return 0;
    },

    async joinRoom(code, name) {
      const nm = name.trim();
      if (nm.length < 1 || nm.length > 40) fail('Use a name between 1 and 40 characters.');
      const me = uid();
      const m = mutate((db) => {
        const s = db.sessions.find((x) => x.room_code === code.trim().toUpperCase()) ?? fail('No room uses that code. Check it with your host.');
        if (s.stage === 'ended') fail('This session has ended.');
        let p = db.participants.find((x) => x.session_id === s.id && x.auth_user_id === me);
        if (!p) {
          if (db.participants.filter((x) => x.session_id === s.id).length >= 120) fail('This room is full.');
          p = { id: uuid(), session_id: s.id, auth_user_id: me, name: nm, joined_at: now() };
          db.participants.push(p);
        } else {
          p.name = nm;
        }
        for (let i = 1; i <= s.current_phase; i++) {
          const cat = PHASE_CATS[i - 1];
          if (!db.assignments.some((a) => a.participant_id === p!.id && a.category === cat)) {
            const cid = pickCard(db, s.id, cat, s.distribution_mode);
            if (cid) db.assignments.push({ id: uuid(), session_id: s.id, participant_id: p.id, card_id: cid, category: cat, revealed: true });
          }
        }
        if (s.current_phase < 4) {
          const cat = PHASE_CATS[s.current_phase];
          const previewing = db.assignments.some((a) => a.session_id === s.id && a.category === cat && !a.revealed);
          if (previewing && !db.assignments.some((a) => a.participant_id === p!.id && a.category === cat)) {
            const cid = pickCard(db, s.id, cat, s.distribution_mode);
            if (cid) db.assignments.push({ id: uuid(), session_id: s.id, participant_id: p.id, card_id: cid, category: cat, revealed: false });
          }
        }
        return { sessionId: s.id, participantId: p.id, code: s.room_code, name: p.name };
      });
      writeMember(m);
      return m;
    },

    recallMembership(code) {
      return readMember(code.toUpperCase());
    },

    lastMembership() {
      try {
        const raw = sessionStorage.getItem('dt-demo-last-member');
        return raw ? (JSON.parse(raw) as Membership) : null;
      } catch {
        const raw = memoryMembers.get('__last');
        return raw ? (JSON.parse(raw) as Membership) : null;
      }
    },

    forgetMembership(code) {
      try {
        sessionStorage.removeItem(membersKey(code));
        const last = sessionStorage.getItem('dt-demo-last-member');
        if (last && (JSON.parse(last) as Membership).code === code) sessionStorage.removeItem('dt-demo-last-member');
      } catch {
        memoryMembers.delete(code);
      }
    },

    async getSession(sessionId) {
      const db = load();
      const me = uid();
      const s = db.sessions.find((x) => x.id === sessionId);
      if (!s) return null;
      // Players only see sessions they belong to; the demo host sees all of them.
      const member = db.participants.some((p) => p.session_id === sessionId && p.auth_user_id === me);
      return member || isHostTab() ? { ...s } : null;
    },

    async getRoster(sessionId) {
      return load().participants.filter((p) => p.session_id === sessionId).sort((a, b) => a.joined_at.localeCompare(b.joined_at)).map(strip);
    },

    async myHand(sessionId) {
      const db = load();
      const me = uid();
      const mine = db.participants.find((p) => p.session_id === sessionId && p.auth_user_id === me);
      if (!mine) return [];
      return db.assignments
        .filter((a) => a.participant_id === mine.id && a.revealed)
        .map((a): HandCard | null => {
          const c = db.cards.find((x) => x.id === a.card_id);
          return c ? { phase: PHASE_CATS.indexOf(a.category) + 1, category: a.category, title: c.title, content: c.content } : null;
        })
        .filter((x): x is HandCard => x !== null)
        .sort((a, b) => a.phase - b.phase);
    },

    watchSession(_sessionId, _scope, onChange) {
      listeners.add(onChange);
      return () => {
        listeners.delete(onChange);
      };
    },

    room(sessionId) {
      return new DemoRoom(sessionId);
    },

    async hostState(): Promise<HostState> {
      markHostTab();
      return { signedIn: true, isHost: true, email: 'Demo host' };
    },
    onHostChange() {
      return () => undefined;
    },
    async hostSignIn() {
      /* no sign-in in demo mode */
    },
    async hostSignOut() {
      /* no sign-in in demo mode */
    },

    async listSessions() {
      const db = load();
      return db.sessions
        .map((s) => ({ ...s, player_count: db.participants.filter((p) => p.session_id === s.id).length }))
        .sort((a, b) => b.created_at.localeCompare(a.created_at));
    },

    async createSession(title) {
      return mutate((db) => {
        let code = '';
        do {
          code = Array.from({ length: 5 }, () => ALPHABET[Math.floor(Math.random() * ALPHABET.length)]).join('');
        } while (db.sessions.some((s) => s.room_code === code));
        const s: Session = {
          id: uuid(), room_code: code, title: title.trim().slice(0, 80), brief: '', stage: 'lobby', current_phase: 0,
          paused: false, ends_at: null, paused_remaining_seconds: null, briefing_seconds: 300, phase_seconds: 600,
          distribution_mode: 'balanced', deal_seq: 0, created_at: now(),
        };
        db.sessions.push(s);
        return { ...s };
      });
    },

    async deleteSession(sessionId) {
      mutate((db) => {
        db.sessions = db.sessions.filter((s) => s.id !== sessionId);
        db.participants = db.participants.filter((p) => p.session_id !== sessionId);
        db.assignments = db.assignments.filter((a) => a.session_id !== sessionId);
      });
    },

    async updateSession(sessionId, patch: SessionPatch) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        Object.assign(s, patch);
      });
    },

    async startBriefing(sessionId) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        if (s.stage !== 'lobby') fail('The briefing has already started.');
        if (!s.brief.trim()) fail('Write and save the project brief before starting.');
        s.stage = 'briefing';
        s.paused = false;
        s.paused_remaining_seconds = null;
        s.ends_at = addSeconds(null, s.briefing_seconds);
        preparePreview(db, sessionId);
      });
    },

    async dealPhase(sessionId) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        if (s.stage === 'ended') fail('This session has ended.');
        if (s.current_phase >= 4) fail('All four phases are already dealt.');
        if (!s.brief.trim()) fail('Write and save the project brief before dealing.');
        preparePreview(db, sessionId);
        const next = s.current_phase + 1;
        const cat = PHASE_CATS[next - 1];
        db.assignments.forEach((a) => {
          if (a.session_id === sessionId && a.category === cat) a.revealed = true;
        });
        s.stage = 'phase';
        s.current_phase = next;
        s.paused = false;
        s.paused_remaining_seconds = null;
        s.ends_at = addSeconds(null, s.phase_seconds);
        s.deal_seq += 1;
        preparePreview(db, sessionId);
      });
    },

    async pause(sessionId) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        if (s.paused || !s.ends_at || (s.stage !== 'briefing' && s.stage !== 'phase')) return;
        s.paused = true;
        s.paused_remaining_seconds = Math.max(0, Math.ceil((Date.parse(s.ends_at) - Date.now()) / 1000));
      });
    },

    async resume(sessionId) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        if (!s.paused) return;
        s.paused = false;
        s.ends_at = addSeconds(null, s.paused_remaining_seconds ?? 0);
        s.paused_remaining_seconds = null;
      });
    },

    async addTime(sessionId, seconds) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        if (s.stage !== 'briefing' && s.stage !== 'phase') return;
        if (s.paused) s.paused_remaining_seconds = (s.paused_remaining_seconds ?? 0) + seconds;
        else s.ends_at = addSeconds(s.ends_at, seconds);
      });
    },

    async endSession(sessionId) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        s.stage = 'ended';
        s.paused = false;
        s.paused_remaining_seconds = null;
        s.ends_at = null;
        db.assignments = db.assignments.filter((a) => !(a.session_id === sessionId && !a.revealed));
      });
    },

    async reshuffle(sessionId) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        if (s.stage === 'ended' || s.current_phase >= 4) return;
        const cat = PHASE_CATS[s.current_phase];
        db.assignments = db.assignments.filter((a) => !(a.session_id === sessionId && !a.revealed && a.category === cat));
        preparePreview(db, sessionId);
      });
    },

    async reroll(sessionId, participantId) {
      mutate((db) => {
        const s = findSession(db, sessionId);
        if (s.stage === 'ended' || s.current_phase >= 4) fail('There is no upcoming phase to reroll.');
        const cat = PHASE_CATS[s.current_phase];
        const a = db.assignments.find((x) => x.session_id === sessionId && x.participant_id === participantId && x.category === cat && !x.revealed);
        if (!a) {
          preparePreview(db, sessionId);
          return;
        }
        a.card_id = pickCard(db, sessionId, cat, s.distribution_mode, a.card_id) ?? a.card_id;
      });
    },

    async removePlayer(participantId) {
      mutate((db) => {
        db.participants = db.participants.filter((p) => p.id !== participantId);
        db.assignments = db.assignments.filter((a) => a.participant_id !== participantId);
      });
    },

    async hostRoster(sessionId) {
      const db = load();
      const participants = db.participants.filter((p) => p.session_id === sessionId).sort((a, b) => a.joined_at.localeCompare(b.joined_at)).map(strip);
      const assignments: HostAssignment[] = db.assignments
        .filter((a) => a.session_id === sessionId)
        .map((a) => ({ ...a, title: db.cards.find((c) => c.id === a.card_id)?.title ?? 'Missing card' }));
      return { participants, assignments };
    },

    async listCards() {
      return load().cards.slice().sort((a, b) => a.created_at.localeCompare(b.created_at));
    },

    async saveCard(card: CardDraft) {
      const title = card.title.trim();
      if (!title) fail('Give the card a title.');
      if (title.length > 120) fail('Keep the title under 120 characters.');
      if (card.content.length > 600) fail('Keep the description under 600 characters.');
      mutate((db) => {
        if (card.id) {
          const c = db.cards.find((x) => x.id === card.id) ?? fail('Card not found.');
          Object.assign(c, { category: card.category, title, content: card.content.trim(), enabled: card.enabled });
        } else {
          db.cards.push({ id: uuid(), category: card.category, title, content: card.content.trim(), enabled: card.enabled, created_at: now() });
        }
      });
    },

    async setCardEnabled(cardId, enabled) {
      mutate((db) => {
        const c = db.cards.find((x) => x.id === cardId);
        if (c) c.enabled = enabled;
      });
    },

    async deleteCard(cardId) {
      mutate((db) => {
        if (db.assignments.some((a) => a.card_id === cardId)) {
          fail('This card has been dealt in a session, so it cannot be deleted. Switch it off instead.');
        }
        db.cards = db.cards.filter((c) => c.id !== cardId);
      });
    },
  };
}

function markHostTab() {
  try {
    sessionStorage.setItem('dt-demo-host', '1');
  } catch {
    hostFlag = true;
  }
}
let hostFlag = false;
function isHostTab(): boolean {
  try {
    return sessionStorage.getItem('dt-demo-host') === '1' || hostFlag;
  } catch {
    return hostFlag;
  }
}
