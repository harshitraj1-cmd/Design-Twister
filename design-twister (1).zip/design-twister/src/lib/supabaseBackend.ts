// Live backend: Supabase database, anonymous sign-in for players and email sign-in for hosts.
// Game rules run in the database (supabase/migrations); this file only calls them.
import { createClient, type RealtimeChannel, type SupabaseClient } from '@supabase/supabase-js';
import type {
  Backend, Card, CardDraft, HandCard, HostAssignment, HostState, Membership, Participant, Room, Session, SessionPatch,
} from './types';

function check<T>(res: { data: T; error: { message: string } | null }): T {
  if (res.error) throw new Error(res.error.message);
  return res.data;
}

const MEMBER_KEY = (code: string) => 'dt-member-' + code;

class LiveRoom implements Room {
  private ch: RealtimeChannel;
  private reactionCbs = new Set<(e: string) => void>();
  private presenceCbs = new Set<(ids: Set<string>) => void>();
  private ready: Promise<void>;
  private trackId: string | null = null;

  constructor(private sb: SupabaseClient, sessionId: string) {
    this.ch = sb.channel('room-' + sessionId, { config: { broadcast: { self: false }, presence: { key: '' } } });
    this.ch.on('broadcast', { event: 'react' }, ({ payload }) => {
      const emoji = (payload as { emoji?: string })?.emoji;
      if (emoji) this.reactionCbs.forEach((cb) => cb(emoji));
    });
    this.ch.on('presence', { event: 'sync' }, () => this.emitPresence());
    this.ready = new Promise((resolve) => {
      this.ch.subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          if (this.trackId) void this.ch.track({ pid: this.trackId });
          resolve();
        }
      });
    });
  }

  private emitPresence() {
    const ids = new Set<string>();
    const state = this.ch.presenceState() as Record<string, Array<{ pid?: string }>>;
    Object.values(state).forEach((metas) => metas.forEach((m) => m.pid && ids.add(m.pid)));
    if (this.trackId) ids.add(this.trackId);
    this.presenceCbs.forEach((cb) => cb(ids));
  }

  send(emoji: string) {
    void this.ready.then(() => this.ch.send({ type: 'broadcast', event: 'react', payload: { emoji } }));
    this.reactionCbs.forEach((cb) => cb(emoji));
  }
  onReaction(cb: (e: string) => void) {
    this.reactionCbs.add(cb);
    return () => this.reactionCbs.delete(cb);
  }
  track(pid: string) {
    this.trackId = pid;
    void this.ready.then(() => this.ch.track({ pid }));
  }
  onPresence(cb: (ids: Set<string>) => void) {
    this.presenceCbs.add(cb);
    this.emitPresence();
    return () => this.presenceCbs.delete(cb);
  }
  close() {
    this.reactionCbs.clear();
    this.presenceCbs.clear();
    void this.sb.removeChannel(this.ch);
  }
}

export function createSupabaseBackend(url: string, anonKey: string): Backend {
  const sb = createClient(url, anonKey, {
    auth: { persistSession: true, autoRefreshToken: true, storageKey: 'dt-auth' },
    realtime: { params: { eventsPerSecond: 20 } },
  });

  async function ensurePlayer(): Promise<string> {
    const { data } = await sb.auth.getSession();
    if (data.session?.user) return data.session.user.id;
    const res = await sb.auth.signInAnonymously();
    if (res.error || !res.data.user) {
      throw new Error('Could not start a player session. Ask your host to switch on anonymous sign-ins in Supabase.');
    }
    return res.data.user.id;
  }

  const rpc = async <T = unknown>(fn: string, args: Record<string, unknown> = {}): Promise<T> =>
    check(await sb.rpc(fn, args)) as T;

  return {
    mode: 'live',

    async serverOffset() {
      let best = { rtt: Infinity, offset: 0 };
      for (let i = 0; i < 3; i++) {
        const t0 = Date.now();
        const server = await rpc<number>('server_now');
        const t1 = Date.now();
        if (t1 - t0 < best.rtt) best = { rtt: t1 - t0, offset: Number(server) - (t0 + t1) / 2 };
      }
      return best.offset;
    },

    async joinRoom(code, name) {
      await ensurePlayer();
      const p = await rpc<Participant>('join_session', { code, player_name: name });
      const s = check(await sb.from('sessions').select('room_code').eq('id', p.session_id).single()) as { room_code: string };
      const m: Membership = { sessionId: p.session_id, participantId: p.id, code: s.room_code, name: p.name };
      try {
        localStorage.setItem(MEMBER_KEY(m.code), JSON.stringify(m));
        localStorage.setItem('dt-last-member', JSON.stringify(m));
      } catch {
        /* storage blocked */
      }
      return m;
    },

    recallMembership(code) {
      try {
        const raw = localStorage.getItem(MEMBER_KEY(code.toUpperCase()));
        return raw ? (JSON.parse(raw) as Membership) : null;
      } catch {
        return null;
      }
    },

    lastMembership() {
      try {
        const raw = localStorage.getItem('dt-last-member');
        return raw ? (JSON.parse(raw) as Membership) : null;
      } catch {
        return null;
      }
    },

    forgetMembership(code) {
      try {
        localStorage.removeItem(MEMBER_KEY(code));
        const last = localStorage.getItem('dt-last-member');
        if (last && (JSON.parse(last) as Membership).code === code) localStorage.removeItem('dt-last-member');
      } catch {
        /* storage blocked */
      }
    },

    async getSession(sessionId) {
      const res = await sb.from('sessions').select('*').eq('id', sessionId).maybeSingle();
      return (check(res) as Session | null) ?? null;
    },

    async getRoster(sessionId) {
      const res = await sb.from('participants').select('id, session_id, name, joined_at').eq('session_id', sessionId).order('joined_at');
      return check(res) as Participant[];
    },

    async myHand(sessionId) {
      return (await rpc<HandCard[]>('my_hand', { sid: sessionId })) ?? [];
    },

    watchSession(sessionId, scope, onChange) {
      const ch = sb.channel('watch-' + sessionId + '-' + Math.random().toString(36).slice(2));
      ch.on('postgres_changes', { event: '*', schema: 'public', table: 'sessions', filter: `id=eq.${sessionId}` }, onChange);
      ch.on('postgres_changes', { event: '*', schema: 'public', table: 'participants', filter: `session_id=eq.${sessionId}` }, onChange);
      if (scope.host) {
        ch.on('postgres_changes', { event: '*', schema: 'public', table: 'assignments', filter: `session_id=eq.${sessionId}` }, onChange);
      } else if (scope.participantId) {
        ch.on('postgres_changes', { event: '*', schema: 'public', table: 'assignments', filter: `participant_id=eq.${scope.participantId}` }, onChange);
      }
      ch.subscribe((status) => {
        if (status === 'SUBSCRIBED') onChange();
      });
      return () => {
        void sb.removeChannel(ch);
      };
    },

    room(sessionId) {
      return new LiveRoom(sb, sessionId);
    },

    async hostState(): Promise<HostState> {
      const { data } = await sb.auth.getSession();
      const user = data.session?.user;
      if (!user || user.is_anonymous) return { signedIn: false, isHost: false };
      const roles = check(await sb.from('user_roles').select('role').eq('user_id', user.id)) as Array<{ role: string }>;
      return { signedIn: true, isHost: roles.some((r) => r.role === 'admin'), email: user.email ?? undefined };
    },

    onHostChange(cb) {
      const { data } = sb.auth.onAuthStateChange(() => cb());
      return () => data.subscription.unsubscribe();
    },

    async hostSignIn(email, password) {
      const res = await sb.auth.signInWithPassword({ email: email.trim(), password });
      if (res.error) throw new Error(res.error.message === 'Invalid login credentials' ? 'That email and password do not match a host account.' : res.error.message);
    },

    async hostSignOut() {
      await sb.auth.signOut();
    },

    async listSessions() {
      const res = await sb.from('sessions').select('*, participants(count)').order('created_at', { ascending: false });
      const rows = check(res) as Array<Session & { participants: Array<{ count: number }> }>;
      return rows.map(({ participants, ...s }) => ({ ...s, player_count: participants?.[0]?.count ?? 0 }));
    },

    async createSession(title) {
      return rpc<Session>('create_session', { session_title: title });
    },

    async deleteSession(sessionId) {
      check(await sb.from('sessions').delete().eq('id', sessionId));
    },

    async updateSession(sessionId, patch: SessionPatch) {
      check(await sb.from('sessions').update(patch).eq('id', sessionId));
    },

    async startBriefing(sessionId) {
      await rpc('start_briefing', { sid: sessionId });
    },
    async dealPhase(sessionId) {
      await rpc('deal_phase', { sid: sessionId });
    },
    async pause(sessionId) {
      await rpc('pause_session', { sid: sessionId });
    },
    async resume(sessionId) {
      await rpc('resume_session', { sid: sessionId });
    },
    async addTime(sessionId, seconds) {
      await rpc('add_time', { sid: sessionId, secs: seconds });
    },
    async endSession(sessionId) {
      await rpc('end_session', { sid: sessionId });
    },
    async reshuffle(sessionId) {
      await rpc('reshuffle_preview', { sid: sessionId });
    },
    async reroll(sessionId, participantId) {
      await rpc('reroll_card', { sid: sessionId, pid: participantId });
    },
    async removePlayer(participantId) {
      check(await sb.from('participants').delete().eq('id', participantId));
    },

    async hostRoster(sessionId) {
      const [p, a] = await Promise.all([
        sb.from('participants').select('id, session_id, name, joined_at').eq('session_id', sessionId).order('joined_at'),
        sb.from('assignments').select('id, session_id, participant_id, card_id, category, revealed, cards(title)').eq('session_id', sessionId),
      ]);
      const participants = check(p) as Participant[];
      const raw = check(a) as Array<Omit<HostAssignment, 'title'> & { cards: { title: string } | null }>;
      const assignments: HostAssignment[] = raw.map(({ cards, ...rest }) => ({ ...rest, title: cards?.title ?? 'Missing card' }));
      return { participants, assignments };
    },

    async listCards() {
      return check(await sb.from('cards').select('*').order('created_at')) as Card[];
    },

    async saveCard(card: CardDraft) {
      const row = { category: card.category, title: card.title.trim(), content: card.content.trim(), enabled: card.enabled };
      if (!row.title) throw new Error('Give the card a title.');
      if (card.id) check(await sb.from('cards').update(row).eq('id', card.id));
      else check(await sb.from('cards').insert(row));
    },

    async setCardEnabled(cardId, enabled) {
      check(await sb.from('cards').update({ enabled }).eq('id', cardId));
    },

    async deleteCard(cardId) {
      const res = await sb.from('cards').delete().eq('id', cardId);
      if (res.error) {
        if (res.error.message.includes('foreign key')) {
          throw new Error('This card has been dealt in a session, so it cannot be deleted. Switch it off instead.');
        }
        throw new Error(res.error.message);
      }
    },
  };
}
