import { useEffect, useState } from 'react';
import { DEMO_MODE, SUPABASE_ANON_KEY, SUPABASE_URL } from './config';
import { createDemoBackend } from './demoBackend';
import type { Backend } from './types';

let instance: Promise<Backend> | null = null;

/** Loads the Supabase client only when a project is configured, so demo builds stay small. */
export function getBackend(): Promise<Backend> {
  if (!instance) {
    instance = DEMO_MODE
      ? Promise.resolve(createDemoBackend())
      : import('./supabaseBackend').then((m) => m.createSupabaseBackend(SUPABASE_URL, SUPABASE_ANON_KEY));
  }
  return instance;
}

let resolved: Backend | null = null;
export function useBackend(): Backend | null {
  const [b, setB] = useState<Backend | null>(resolved);
  useEffect(() => {
    if (!b) {
      void getBackend().then((x) => {
        resolved = x;
        setB(x);
      });
    }
  }, [b]);
  return b;
}

let offsetPromise: Promise<number> | null = null;
/** Milliseconds to add to Date.now() to match the server clock. */
export function useServerOffset(backend: Backend | null): number {
  const [offset, setOffset] = useState(0);
  useEffect(() => {
    if (!backend) return;
    if (!offsetPromise) offsetPromise = backend.serverOffset().catch(() => 0);
    void offsetPromise.then(setOffset);
  }, [backend]);
  return offset;
}

/** Re-renders every `ms` and returns the current time in milliseconds. */
export function useNow(ms = 250): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(t);
  }, [ms]);
  return now;
}

export function debounce(fn: () => void, ms: number): () => void {
  let t: number | undefined;
  return () => {
    window.clearTimeout(t);
    t = window.setTimeout(fn, ms);
  };
}
