export type Category = 'design_brief' | 'budget_material' | 'spatial_rules' | 'wildcard';
export type Stage = 'lobby' | 'briefing' | 'phase' | 'ended';
export type DealMode = 'balanced' | 'random';

export interface Session {
  id: string;
  room_code: string;
  title: string;
  brief: string;
  stage: Stage;
  current_phase: number;
  paused: boolean;
  ends_at: string | null;
  paused_remaining_seconds: number | null;
  briefing_seconds: number;
  phase_seconds: number;
  distribution_mode: DealMode;
  deal_seq: number;
  created_at: string;
}

export interface Participant {
  id: string;
  session_id: string;
  name: string;
  joined_at: string;
}

export interface Card {
  id: string;
  category: Category;
  title: string;
  content: string;
  enabled: boolean;
  created_at: string;
}

export interface Assignment {
  id: string;
  session_id: string;
  participant_id: string;
  card_id: string;
  category: Category;
  revealed: boolean;
}

/** An assignment with its card text, as the host console shows it. */
export interface HostAssignment extends Assignment {
  title: string;
}

export interface HandCard {
  phase: number;
  category: Category;
  title: string;
  content: string;
}

export interface Membership {
  sessionId: string;
  participantId: string;
  code: string;
  name: string;
}

export interface HostState {
  signedIn: boolean;
  isHost: boolean;
  email?: string;
}

export type SessionPatch = Partial<Pick<Session, 'title' | 'brief' | 'briefing_seconds' | 'phase_seconds' | 'distribution_mode'>>;

export interface CardDraft {
  id?: string;
  category: Category;
  title: string;
  content: string;
  enabled: boolean;
}

/** Live, unstored room traffic: emoji reactions and who has the game open. */
export interface Room {
  send(emoji: string): void;
  onReaction(cb: (emoji: string) => void): () => void;
  track(participantId: string): void;
  onPresence(cb: (online: Set<string>) => void): () => void;
  close(): void;
}

export interface Backend {
  mode: 'demo' | 'live';

  serverOffset(): Promise<number>;

  // players
  joinRoom(code: string, name: string): Promise<Membership>;
  recallMembership(code: string): Membership | null;
  lastMembership(): Membership | null;
  forgetMembership(code: string): void;
  getSession(sessionId: string): Promise<Session | null>;
  getRoster(sessionId: string): Promise<Participant[]>;
  myHand(sessionId: string): Promise<HandCard[]>;
  watchSession(sessionId: string, scope: { participantId?: string; host?: boolean }, onChange: () => void): () => void;
  room(sessionId: string): Room;

  // hosts
  hostState(): Promise<HostState>;
  onHostChange(cb: () => void): () => void;
  hostSignIn(email: string, password: string): Promise<void>;
  hostSignOut(): Promise<void>;
  listSessions(): Promise<Array<Session & { player_count: number }>>;
  createSession(title: string): Promise<Session>;
  deleteSession(sessionId: string): Promise<void>;
  updateSession(sessionId: string, patch: SessionPatch): Promise<void>;
  startBriefing(sessionId: string): Promise<void>;
  dealPhase(sessionId: string): Promise<void>;
  pause(sessionId: string): Promise<void>;
  resume(sessionId: string): Promise<void>;
  addTime(sessionId: string, seconds: number): Promise<void>;
  endSession(sessionId: string): Promise<void>;
  reshuffle(sessionId: string): Promise<void>;
  reroll(sessionId: string, participantId: string): Promise<void>;
  removePlayer(participantId: string): Promise<void>;
  hostRoster(sessionId: string): Promise<{ participants: Participant[]; assignments: HostAssignment[] }>;

  // card library
  listCards(): Promise<Card[]>;
  saveCard(card: CardDraft): Promise<void>;
  setCardEnabled(cardId: string, enabled: boolean): Promise<void>;
  deleteCard(cardId: string): Promise<void>;
}
