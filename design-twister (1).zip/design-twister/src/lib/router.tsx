// A small router with three modes, so the same app runs on a real domain, a static host or inside an embed.
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type AnchorHTMLAttributes, type MouseEvent, type ReactNode } from 'react';

type Mode = 'browser' | 'hash' | 'memory';
interface RouterValue {
  path: string;
  mode: Mode;
  navigate: (to: string, opts?: { replace?: boolean }) => void;
  href: (to: string) => string;
}

const Ctx = createContext<RouterValue>({ path: '/', mode: 'memory', navigate: () => undefined, href: (t) => t });

function readPath(mode: Mode): string {
  if (mode === 'browser') return window.location.pathname || '/';
  if (mode === 'hash') return window.location.hash.replace(/^#/, '') || '/';
  return '/';
}

export function Router({ mode, children }: { mode: Mode; children: ReactNode }) {
  const [path, setPath] = useState(() => readPath(mode));

  useEffect(() => {
    if (mode === 'memory') return;
    const onChange = () => setPath(readPath(mode));
    window.addEventListener(mode === 'browser' ? 'popstate' : 'hashchange', onChange);
    return () => window.removeEventListener(mode === 'browser' ? 'popstate' : 'hashchange', onChange);
  }, [mode]);

  const navigate = useCallback(
    (to: string, opts?: { replace?: boolean }) => {
      if (mode === 'browser') {
        if (opts?.replace) window.history.replaceState(null, '', to);
        else window.history.pushState(null, '', to);
      } else if (mode === 'hash') {
        if (opts?.replace) window.location.replace('#' + to);
        else window.location.hash = to;
      }
      setPath(to);
      window.scrollTo(0, 0);
    },
    [mode],
  );

  const href = useCallback((to: string) => (mode === 'browser' ? to : mode === 'hash' ? '#' + to : '#'), [mode]);
  const value = useMemo(() => ({ path, mode, navigate, href }), [path, mode, navigate, href]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useRouter = () => useContext(Ctx);

/** Matches '/play/:code' against '/play/K7P2Q' and returns { code: 'K7P2Q' }. */
export function match(pattern: string, path: string): Record<string, string> | null {
  const p = pattern.split('/').filter(Boolean);
  const s = path.split('?')[0].split('/').filter(Boolean);
  if (p.length !== s.length) return null;
  const out: Record<string, string> = {};
  for (let i = 0; i < p.length; i++) {
    if (p[i].startsWith(':')) out[p[i].slice(1)] = decodeURIComponent(s[i]);
    else if (p[i] !== s[i]) return null;
  }
  return out;
}

/** Full shareable URL for an in-app path, or null in memory mode where paths are not shareable. */
export function absoluteUrl(mode: Mode, to: string): string | null {
  if (mode === 'memory') return null;
  const base = window.location.origin + (mode === 'hash' ? window.location.pathname + '#' : '');
  return base + to;
}

export function Link({ to, children, onClick, ...rest }: { to: string; children: ReactNode } & AnchorHTMLAttributes<HTMLAnchorElement>) {
  const { navigate, href } = useRouter();
  const handle = (e: MouseEvent<HTMLAnchorElement>) => {
    onClick?.(e);
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    e.preventDefault();
    navigate(to);
  };
  return (
    <a href={href(to)} onClick={handle} {...rest}>
      {children}
    </a>
  );
}
