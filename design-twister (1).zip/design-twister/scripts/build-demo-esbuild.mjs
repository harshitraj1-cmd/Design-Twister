// Builds the in-browser demo with esbuild alone (no Vite needed).
// Writes dist-demo/index.html (a normal page) and dist-demo/design-twister-demo.html (artifact format).
// Set ROUTER=hash to get shareable #/paths in the normal page.
import * as esbuild from 'esbuild';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const out = path.join(root, 'dist-demo');
mkdirSync(out, { recursive: true });

const noSupabase = {
  name: 'no-supabase',
  setup(build) {
    build.onResolve({ filter: /supabaseBackend$/ }, () => ({ path: 'supabase-stub', namespace: 'stub' }));
    build.onLoad({ filter: /.*/, namespace: 'stub' }, () => ({
      contents: 'export function createSupabaseBackend(){throw new Error("The demo build has no live backend.")}',
      loader: 'js',
    }));
  },
};

const result = await esbuild.build({
  entryPoints: [path.join(root, 'src/main.tsx')],
  bundle: true,
  format: 'esm',
  minify: true,
  write: false,
  outdir: out,
  jsx: 'automatic',
  target: ['es2020'],
  loader: { '.json': 'json' },
  nodePaths: (process.env.NODE_PATH || '').split(':').filter(Boolean),
  define: {
    'import.meta.env': JSON.stringify({ VITE_DEMO: '1', VITE_ROUTER: process.env.ROUTER || 'memory' }),
    'process.env.NODE_ENV': '"production"',
  },
  plugins: [noSupabase],
  logLevel: 'warning',
});

const js = result.outputFiles.find((f) => f.path.endsWith('.js')).text.replace(/<\/script/gi, '<\\/script');
const css = result.outputFiles.find((f) => f.path.endsWith('.css')).text;
const template = readFileSync(path.join(root, 'index.html'), 'utf8');
const page = template
  .replace(/<script type="module" src="[^"]+"><\/script>/, () => `<script type="module">${js}</script>`)
  .replace('</head>', () => `<style>${css}</style>\n</head>`)
  .replace('<title>Design Twister</title>', '<title>Design Twister Demo</title>');
writeFileSync(path.join(out, 'index.html'), page);
console.log(`Wrote dist-demo/index.html (${(page.length / 1024).toFixed(0)} KB)`);
execFileSync(process.execPath, [path.join(root, 'scripts/to-artifact.mjs'), path.join(out, 'index.html'), path.join(out, 'design-twister-demo.html')], { stdio: 'inherit' });
