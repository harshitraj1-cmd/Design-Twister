// Writes supabase/seed.sql from src/lib/seedCards.json so both backends share one card list.
import { readFileSync, writeFileSync } from 'node:fs';

const cards = JSON.parse(readFileSync(new URL('../src/lib/seedCards.json', import.meta.url), 'utf8'));
const q = (s) => "'" + String(s).replace(/'/g, "''") + "'";
const rows = cards.map((c) => `  (${q(c.category)}, ${q(c.title)}, ${q(c.content)})`).join(',\n');
const sql = `-- Design Twister 2 · starter card library (${cards.length} cards)
-- Generated from src/lib/seedCards.json by scripts/make-seed.mjs. Safe to run once.
insert into public.cards (category, title, content) values
${rows};
`;
writeFileSync(new URL('../supabase/seed.sql', import.meta.url), sql);
console.log(`Wrote supabase/seed.sql with ${cards.length} cards`);
