// Turns a built single-file HTML page into the body-only format that claude.ai artifacts expect:
// <title>, links and styles first, then the page markup and scripts, with no html/head/body wrappers.
// Usage: node scripts/to-artifact.mjs <input.html> <output.html>
import { readFileSync, writeFileSync } from 'node:fs';

const [, , input, output] = process.argv;
if (!input || !output) {
  console.error('Usage: node scripts/to-artifact.mjs <input.html> <output.html>');
  process.exit(1);
}
const html = readFileSync(input, 'utf8');
const head = (html.match(/<head[^>]*>([\s\S]*?)<\/head>/i) || [, ''])[1];
const body = (html.match(/<body[^>]*>([\s\S]*?)<\/body>/i) || [, html])[1];

const title = (head.match(/<title>[\s\S]*?<\/title>/i) || ['<title>Design Twister</title>'])[0];
const links = head.match(/<link\b[^>]*>/gi) || [];
const styles = [...(head.match(/<style\b[^>]*>[\s\S]*?<\/style>/gi) || []), ...(body.match(/<style\b[^>]*>[\s\S]*?<\/style>/gi) || [])];
const scripts = [...(head.match(/<script\b[^>]*>[\s\S]*?<\/script>/gi) || []), ...(body.match(/<script\b[^>]*>[\s\S]*?<\/script>/gi) || [])];
const markup = body.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '').trim();

// Inside an artifact the viewer pads the page for the phone's notch, so the sticky bar sits below it.
const artifactFix = `<style>.topbar{top:env(safe-area-inset-top,0px);padding-top:0}body::before{content:"";position:fixed;inset:0 0 auto;height:env(safe-area-inset-top,0px);z-index:41;background:var(--bg)}</style>`;

const out = [
  title,
  '<meta name="claude:viewport-fit-sides" content="cover">',
  ...links.filter((l) => /fonts\.(googleapis|gstatic)\.com/.test(l)),
  ...styles,
  artifactFix,
  markup,
  ...scripts.map((s) => s.replace(/\scrossorigin(=["'][^"']*["'])?/i, '')),
].join('\n');

writeFileSync(output, out);
console.log(`Wrote ${output} (${(out.length / 1024).toFixed(0)} KB)`);
