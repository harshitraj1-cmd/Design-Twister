import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// `npm run build` makes the live site in dist/.
// `npm run build:demo` reads .env.demo and makes one self-contained HTML file in dist-demo/
// that runs the whole game inside the browser, with no server.
export default defineConfig(({ mode }) => ({
  plugins: mode === 'demo' ? [react(), viteSingleFile()] : [react()],
  build: { outDir: mode === 'demo' ? 'dist-demo' : 'dist' },
}));
